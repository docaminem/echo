import { ValveRecommendations } from '../../types/recommendations';

export function getMitralStenosisRecommendations(
  severity: string,
  wilkinsScore: number = 8,
  hasThrombus: boolean = false,
  hasMR: boolean = false
): ValveRecommendations {
  if (severity === 'Sévère') {
    // Sténose mitrale sévère avec anatomie favorable
    if (wilkinsScore <= 8 && !hasThrombus) {
      return {
        treatment: [
          {
            indication: 'Valvuloplastie mitrale percutanée',
            class: 'I',
            levelOfEvidence: 'A',
            description: 'Première intention si anatomie favorable (score de Wilkins ≤ 8)'
          }
        ],
        followUp: [
          'Échocardiographie à 24-48h',
          'Suivi à 1, 6 et 12 mois',
          'Anticoagulation si FA ou antécédent embolique'
        ],
        additionalConsiderations: [
          'Évaluation de l\'HTAP',
          'Recherche de FA',
          'Prophylaxie de l\'endocardite'
        ]
      };
    }

    // Sténose mitrale sévère avec anatomie défavorable
    return {
      treatment: [
        {
          indication: 'Remplacement valvulaire mitral',
          class: 'I',
          levelOfEvidence: 'C',
          description: 'Si anatomie défavorable ou contre-indication à la valvuloplastie'
        }
      ],
      followUp: [
        'Échocardiographie post-opératoire',
        'Suivi à 1, 6 et 12 mois',
        'Anticoagulation à vie si valve mécanique'
      ],
      additionalConsiderations: [
        'Choix du type de prothèse',
        'Évaluation du risque hémorragique',
        'Gestion de l\'anticoagulation'
      ]
    };
  }

  return {
    treatment: [
      {
        indication: 'Surveillance',
        class: 'I',
        levelOfEvidence: 'C',
        description: 'Suivi clinique et échographique régulier'
      }
    ],
    followUp: [
      'Échocardiographie annuelle',
      'Surveillance des symptômes',
      'Prophylaxie de l\'endocardite'
    ]
  };
}

export function getMitralInsufficiencyRecommendations(
  severity: string,
  ef: number,
  symptoms: boolean = true,
  isIschemic: boolean = false
): ValveRecommendations {
  if (severity === 'Sévère') {
    // IM sévère symptomatique
    if (symptoms) {
      return {
        treatment: [
          {
            indication: 'Plastie mitrale',
            class: 'I',
            levelOfEvidence: 'B',
            description: 'Première intention si anatomie favorable'
          },
          {
            indication: 'Remplacement valvulaire',
            class: 'I',
            levelOfEvidence: 'B',
            description: 'Si plastie non réalisable'
          }
        ],
        followUp: [
          'Échocardiographie à 1 mois post-intervention',
          'Suivi à 3, 6 et 12 mois puis annuel',
          'Anticoagulation si valve mécanique',
          'Prophylaxie de l\'endocardite'
        ],
        additionalConsiderations: [
          'Évaluation de la faisabilité d\'une plastie',
          'Discussion Heart Team',
          'Choix du type de prothèse si remplacement'
        ]
      };
    }

    // IM sévère avec dysfonction VG
    if (ef < 50) {
      return {
        treatment: [
          {
            indication: 'Chirurgie',
            class: 'I',
            levelOfEvidence: 'B',
            description: 'Même si asymptomatique si FEVG < 50%'
          }
        ],
        followUp: [
          'Optimisation du traitement médical',
          'Échocardiographie tous les 3-6 mois',
          'Évaluation régulière de la fonction VG'
        ],
        additionalConsiderations: [
          'Timing optimal de la chirurgie',
          'Évaluation du remodelage VG',
          'Discussion Heart Team'
        ]
      };
    }

    // IM sévère asymptomatique avec fonction VG préservée
    return {
      treatment: [
        {
          indication: 'Plastie mitrale',
          class: 'IIa',
          levelOfEvidence: 'B',
          description: 'Si forte probabilité de réparation durable'
        }
      ],
      followUp: [
        'Échocardiographie tous les 6 mois',
        'Test d\'effort annuel',
        'Surveillance des symptômes'
      ],
      additionalConsiderations: [
        'Expérience du centre chirurgical',
        'Préférence du patient',
        'Évaluation du risque chirurgical'
      ]
    };
  }

  return {
    treatment: [
      {
        indication: 'Surveillance',
        class: 'I',
        levelOfEvidence: 'C',
        description: 'Suivi clinique et échographique régulier'
      }
    ],
    followUp: [
      'Échocardiographie annuelle si modérée',
      'Échocardiographie tous les 2-3 ans si légère',
      'Contrôle des facteurs de risque'
    ]
  };
}