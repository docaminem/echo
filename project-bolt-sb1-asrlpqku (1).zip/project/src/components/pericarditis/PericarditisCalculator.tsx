import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

interface Symptom {
  id: string;
  label: string;
  points: number;
}

const symptoms: Symptom[] = [
  { id: 'chest_pain', label: 'Douleur thoracique péricardique', points: 2 },
  { id: 'friction_rub', label: 'Frottement péricardique', points: 2 },
  { id: 'ecg_changes', label: 'Modifications ECG évocatrices', points: 2 },
  { id: 'effusion', label: 'Épanchement péricardique', points: 2 },
  { id: 'crp', label: 'Élévation CRP', points: 1 },
  { id: 'troponin', label: 'Élévation Troponine', points: 1 }
];

export function PericarditisCalculator() {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  
  const toggleSymptom = (id: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(id) 
        ? prev.filter(s => s !== id)
        : [...prev, id]
    );
  };

  const score = selectedSymptoms.reduce((total, id) => {
    const symptom = symptoms.find(s => s.id === id);
    return total + (symptom?.points || 0);
  }, 0);

  const getInterpretation = (score: number) => {
    if (score >= 4) {
      return {
        text: 'Diagnostic de péricardite très probable',
        color: 'text-red-600'
      };
    } else if (score >= 2) {
      return {
        text: 'Diagnostic possible - Investigations complémentaires nécessaires',
        color: 'text-orange-600'
      };
    }
    return {
      text: 'Diagnostic peu probable',
      color: 'text-green-600'
    };
  };

  const interpretation = getInterpretation(score);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
        <Calculator className="w-5 h-5 text-blue-600" />
        Calculateur Diagnostic
      </h2>

      <div className="space-y-4">
        {symptoms.map(symptom => (
          <label 
            key={symptom.id}
            className="flex items-center gap-3 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer"
          >
            <input
              type="checkbox"
              checked={selectedSymptoms.includes(symptom.id)}
              onChange={() => toggleSymptom(symptom.id)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="flex-1">{symptom.label}</span>
            <span className="text-sm text-gray-500">
              {symptom.points} {symptom.points > 1 ? 'points' : 'point'}
            </span>
          </label>
        ))}

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center">
            <span className="font-medium">Score total:</span>
            <span className="text-lg font-bold">{score} points</span>
          </div>
          <p className={`mt-2 font-medium ${interpretation.color}`}>
            {interpretation.text}
          </p>
        </div>
      </div>
    </div>
  );
}