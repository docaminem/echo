import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

interface RiskFactor {
  id: string;
  label: string;
  description: string;
  points: number;
}

const riskFactors: RiskFactor[] = [
  { 
    id: 'hypertension',
    label: 'Hypertension',
    description: 'PAS > 160 mmHg',
    points: 1
  },
  {
    id: 'renal',
    label: 'Insuffisance rénale',
    description: 'Dialyse, transplantation ou créatinine > 200 µmol/L',
    points: 1
  },
  {
    id: 'liver',
    label: 'Insuffisance hépatique',
    description: 'Cirrhose ou bilirubine > 2× normale avec transaminases > 3× normale',
    points: 1
  },
  {
    id: 'stroke',
    label: 'AVC',
    description: 'Antécédent d\'AVC',
    points: 1
  },
  {
    id: 'bleeding',
    label: 'Saignement',
    description: 'Antécédent de saignement ou prédisposition',
    points: 1
  },
  {
    id: 'inr',
    label: 'INR labile',
    description: 'INR instable ou temps dans la cible < 60%',
    points: 1
  },
  {
    id: 'elderly',
    label: 'Âge',
    description: 'Âge > 65 ans',
    points: 1
  },
  {
    id: 'drugs',
    label: 'Médicaments',
    description: 'Antiagrégants, AINS',
    points: 1
  },
  {
    id: 'alcohol',
    label: 'Alcool',
    description: 'Consommation excessive d\'alcool',
    points: 1
  }
];

export function HasBledCalculator() {
  const [selectedFactors, setSelectedFactors] = useState<string[]>([]);

  const toggleFactor = (id: string) => {
    setSelectedFactors(prev => 
      prev.includes(id) 
        ? prev.filter(f => f !== id)
        : [...prev, id]
    );
  };

  const score = selectedFactors.length;

  const getInterpretation = (score: number) => {
    if (score >= 3) {
      return {
        risk: 'Risque hémorragique élevé',
        description: 'Surveillance rapprochée nécessaire',
        color: 'text-red-600'
      };
    }
    if (score === 2) {
      return {
        risk: 'Risque hémorragique modéré',
        description: 'Surveillance régulière recommandée',
        color: 'text-orange-600'
      };
    }
    return {
      risk: 'Risque hémorragique faible',
      description: 'Surveillance habituelle',
      color: 'text-green-600'
    };
  };

  const interpretation = getInterpretation(score);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Calculator className="w-5 h-5 text-blue-600" />
        Score HAS-BLED
      </h2>

      <div className="space-y-4">
        {riskFactors.map(factor => (
          <label 
            key={factor.id}
            className="flex items-center gap-3 p-4 rounded-lg border hover:bg-gray-50 cursor-pointer"
          >
            <input
              type="checkbox"
              checked={selectedFactors.includes(factor.id)}
              onChange={() => toggleFactor(factor.id)}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <div className="flex-1">
              <div className="font-medium text-gray-900">{factor.label}</div>
              <div className="text-sm text-gray-500">{factor.description}</div>
            </div>
            <div className="text-sm font-medium text-gray-500">
              {factor.points} point
            </div>
          </label>
        ))}

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium text-gray-900">Score total:</span>
            <span className="text-2xl font-bold text-blue-900">{score} points</span>
          </div>
          <div className={`font-medium ${interpretation.color}`}>
            {interpretation.risk}
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {interpretation.description}
          </p>
        </div>
      </div>
    </div>
  );
}