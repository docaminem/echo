import React from 'react';
import { cn } from '../../lib/utils';

interface FormFieldProps {
  label: string;
  name: string;
  value: string | number;
  onChange: (value: string) => void;
  type?: 'text' | 'number';
  required?: boolean;
  step?: string;
  className?: string;
  description?: string;
  placeholder?: string;
}

export function FormField({
  label,
  name,
  value,
  onChange,
  type = 'number',
  required = false,
  step = '0.1',
  className,
  description,
  placeholder
}: FormFieldProps) {
  return (
    <div className={cn('space-y-2', className)}>
      <label htmlFor={name} className="block text-sm font-semibold text-gray-900">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      {description && (
        <p className="text-sm text-gray-500">{description}</p>
      )}
      <div className="relative">
        <input
          type={type}
          id={name}
          name={name}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
          step={step}
          placeholder={placeholder}
          className="block w-full rounded-lg border border-gray-300 bg-white px-4 py-3 text-gray-900 
                   focus:border-blue-500 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50
                   placeholder:text-gray-400 disabled:cursor-not-allowed disabled:opacity-50"
        />
      </div>
    </div>
  );
}