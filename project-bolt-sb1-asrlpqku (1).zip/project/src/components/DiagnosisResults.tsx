import React from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Card, Title, Text, Chip } from 'react-native-paper';
import { DiagnosisResult } from '../types/valve';

interface DiagnosisResultsProps {
  results: DiagnosisResult[];
}

export function DiagnosisResults({ results }: DiagnosisResultsProps) {
  if (results.length === 0) {
    return (
      <Card style={styles.card}>
        <Card.Content>
          <Text>Aucune pathologie significative détectée</Text>
        </Card.Content>
      </Card>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {results.map((result, index) => (
        <Card key={index} style={styles.card}>
          <Card.Content>
            <View style={styles.header}>
              <Title>{result.valve} - {result.pathology}</Title>
              <Chip mode="outlined">{result.severity}</Chip>
            </View>
            {result.details.map((detail, i) => (
              <Text key={i} style={styles.detail}>{detail}</Text>
            ))}
          </Card.Content>
        </Card>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  card: {
    margin: 16,
    elevation: 4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  detail: {
    marginVertical: 4,
  }
});