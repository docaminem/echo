import React from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Card, Title, TextInput } from 'react-native-paper';
import { ValveData } from '../types/valve';
import { analyzeValveData } from '../utils/diagnosis';

interface ValveFormProps {
  onResults: (results: any[]) => void;
}

export function ValveForm({ onResults }: ValveFormProps) {
  const handleSubmit = (data: ValveData) => {
    const results = analyzeValveData(data);
    onResults(results);
  };

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Title>Valve Mitrale</Title>
          <View style={styles.inputGroup}>
            <TextInput
              label="Surface Valve (cm²)"
              keyboardType="numeric"
              mode="outlined"
              style={styles.input}
            />
            <TextInput
              label="Gradient Moyen (mmHg)"
              keyboardType="numeric"
              mode="outlined"
              style={styles.input}
            />
          </View>
        </Card.Content>
      </Card>

      {/* Répéter pour les autres valves */}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  card: {
    margin: 16,
    elevation: 4,
  },
  inputGroup: {
    marginTop: 16,
    gap: 12,
  },
  input: {
    backgroundColor: 'white',
  }
});