import React, { useState } from 'react';
import { ArrowDownCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function TricuspidStenosis() {
  const [values, setValues] = useState({
    surface: '',
    meanGradient: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-orange-700">
        <ArrowDownCircle className="w-4 h-4" />
        Sténose Tricuspide
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="Surface Valve"
          name="tricuspidStenosisSurface"
          value={values.surface}
          onChange={handleChange('surface')}
          description="Surface valvulaire tricuspide en cm²"
          placeholder="Ex: 1.8"
          step="0.1"
        />
        <FormField
          label="Gradient Moyen"
          name="tricuspidStenosisMeanGradient"
          value={values.meanGradient}
          onChange={handleChange('meanGradient')}
          description="Gradient moyen transtricuspide en mmHg"
          placeholder="Ex: 3"
          step="0.1"
        />
      </div>
    </div>
  );
}