import React from 'react';

interface ClassificationRow {
  parameter?: string;
  severity?: string;
  criteria: string[];
}

interface ClassificationTableProps {
  title: string;
  headers: string[];
  rows: ClassificationRow[];
}

export function ClassificationTable({ title, headers, rows }: ClassificationTableProps) {
  return (
    <div className="mb-6">
      <h4 className="text-sm font-medium text-gray-700 mb-2">{title}</h4>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 border rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              {headers.map((header, index) => (
                <th
                  key={index}
                  className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {rows.map((row, index) => (
              <tr key={index}>
                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-700">
                  {row.parameter || row.severity}
                </td>
                {row.criteria.map((criterion, idx) => (
                  <td key={idx} className="px-4 py-2 text-sm text-gray-500">
                    {criterion}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}