import React from 'react';
import { Pill } from 'lucide-react';

export function TreatmentGuide() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Pill className="w-5 h-5 text-blue-600" />
        Guide Thérapeutique
      </h2>

      <div className="space-y-6">
        <div>
          <h3 className="font-medium text-gray-900 mb-3">Stratification du Risque</h3>
          <div className="grid gap-4">
            <div className="p-4 bg-red-50 rounded-lg">
              <h4 className="font-medium text-red-900">Haut Risque (EP massive)</h4>
              <div className="mt-2 space-y-3">
                <div>
                  <p className="text-red-800 font-medium">Critères :</p>
                  <ul className="mt-1 space-y-1 text-red-700 list-disc list-inside">
                    <li>Choc ou hypotension persistante</li>
                    <li>Dysfonction VD sévère</li>
                    <li>Thrombus mobile</li>
                  </ul>
                </div>
                <div>
                  <p className="text-red-800 font-medium">Traitement :</p>
                  <ul className="mt-1 space-y-1 text-red-700 list-disc list-inside">
                    <li>Thrombolyse : Alteplase 100mg sur 2h</li>
                    <li>Alternative : Tenecteplase en bolus</li>
                    <li>HNF en parallèle</li>
                    <li>Surveillance en soins intensifs</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="p-4 bg-orange-50 rounded-lg">
              <h4 className="font-medium text-orange-900">Risque Intermédiaire</h4>
              <div className="mt-2 space-y-3">
                <div>
                  <p className="text-orange-800 font-medium">Critères :</p>
                  <ul className="mt-1 space-y-1 text-orange-700 list-disc list-inside">
                    <li>Dysfonction VD sans hypotension</li>
                    <li>Élévation des biomarqueurs</li>
                  </ul>
                </div>
                <div>
                  <p className="text-orange-800 font-medium">Traitement :</p>
                  <ul className="mt-1 space-y-1 text-orange-700 list-disc list-inside">
                    <li>HBPM : Enoxaparine 1mg/kg x 2/j</li>
                    <li>Ou HNF si insuffisance rénale</li>
                    <li>Surveillance hospitalière</li>
                    <li>Réévaluation à 48-72h</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-medium text-green-900">Bas Risque</h4>
              <div className="mt-2 space-y-3">
                <div>
                  <p className="text-green-800 font-medium">Critères :</p>
                  <ul className="mt-1 space-y-1 text-green-700 list-disc list-inside">
                    <li>Pas de dysfonction VD</li>
                    <li>Stabilité hémodynamique</li>
                    <li>Pas de biomarqueurs élevés</li>
                  </ul>
                </div>
                <div>
                  <p className="text-green-800 font-medium">Traitement :</p>
                  <ul className="mt-1 space-y-1 text-green-700 list-disc list-inside">
                    <li>AOD en première intention</li>
                    <li>Rivaroxaban : 15mg x 2/j pendant 21j puis 20mg/j</li>
                    <li>Apixaban : 10mg x 2/j pendant 7j puis 5mg x 2/j</li>
                    <li>Traitement ambulatoire possible</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-medium text-gray-900 mb-3">Anticoagulation</h3>
          <div className="grid gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium">Phase Initiale</h4>
              <div className="mt-2 space-y-2">
                <div>
                  <p className="font-medium text-gray-800">HBPM :</p>
                  <ul className="mt-1 space-y-1 text-gray-600 list-disc list-inside">
                    <li>Enoxaparine 1mg/kg x 2/j SC</li>
                    <li>Ajustement si poids extrême</li>
                    <li>Surveillance plaquettes</li>
                  </ul>
                </div>
                <div>
                  <p className="font-medium text-gray-800">HNF :</p>
                  <ul className="mt-1 space-y-1 text-gray-600 list-disc list-inside">
                    <li>Bolus 80 UI/kg puis 18 UI/kg/h</li>
                    <li>Objectif anti-Xa : 0.3-0.7</li>
                    <li>Si insuffisance rénale sévère</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="p-4 border rounded-lg">
              <h4 className="font-medium">Relais par AOD</h4>
              <div className="mt-2 space-y-2">
                <div>
                  <p className="font-medium text-gray-800">Rivaroxaban :</p>
                  <ul className="mt-1 space-y-1 text-gray-600 list-disc list-inside">
                    <li>15mg x 2/j pendant 21 jours</li>
                    <li>Puis 20mg/j en une prise</li>
                  </ul>
                </div>
                <div>
                  <p className="font-medium text-gray-800">Apixaban :</p>
                  <ul className="mt-1 space-y-1 text-gray-600 list-disc list-inside">
                    <li>10mg x 2/j pendant 7 jours</li>
                    <li>Puis 5mg x 2/j</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-2">Durée du Traitement</h4>
          <div className="space-y-2">
            <div>
              <p className="font-medium text-gray-800">EP provoquée :</p>
              <ul className="mt-1 space-y-1 text-gray-600 list-disc list-inside">
                <li>3-6 mois si facteur transitoire</li>
                <li>Réévaluation à 3 mois</li>
              </ul>
            </div>
            <div>
              <p className="font-medium text-gray-800">EP non provoquée :</p>
              <ul className="mt-1 space-y-1 text-gray-600 list-disc list-inside">
                <li>Minimum 6 mois</li>
                <li>Traitement prolongé à discuter</li>
                <li>Évaluation bénéfice/risque</li>
              </ul>
            </div>
            <div>
              <p className="font-medium text-gray-800">Cancer actif :</p>
              <ul className="mt-1 space-y-1 text-gray-600 list-disc list-inside">
                <li>HBPM pendant 6 mois</li>
                <li>Puis selon évolution du cancer</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}