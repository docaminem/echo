import React, { useState } from 'react';
import { Heart, ArrowDownCircle, ArrowUpCircle } from 'lucide-react';
import { ValveSection } from '../../common/ValveSection';
import { MitralStenosis } from './MitralStenosis';
import { MitralInsufficiency } from './MitralInsufficiency';
import { ClassificationTable } from '../../common/ClassificationTable';
import { mitralStenosisClassification, mitralInsufficiencyClassification } from '../../../data/classifications';

export function MitralValve() {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const sections = [
    {
      id: 'stenosis',
      title: 'Sténose Mitrale',
      icon: ArrowDownCircle,
      component: MitralStenosis,
      classification: mitralStenosisClassification
    },
    {
      id: 'insufficiency',
      title: 'Insuffisance Mitrale',
      icon: ArrowUpCircle,
      component: MitralInsufficiency,
      classification: mitralInsufficiencyClassification
    }
  ];

  return (
    <ValveSection title="Valve Mitrale" icon={Heart}>
      <div className="space-y-4">
        {sections.map(section => (
          <div key={section.id}>
            <button
              onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
              className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                       hover:bg-gray-50 transition-colors duration-200"
            >
              <div className="flex items-center gap-3">
                <section.icon className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-gray-900">{section.title}</span>
              </div>
              <div className="text-blue-600">
                {activeSection === section.id ? '▼' : '▶'}
              </div>
            </button>
            
            {activeSection === section.id && (
              <div className="mt-4 space-y-6">
                <section.component />
                <ClassificationTable {...section.classification} />
              </div>
            )}
          </div>
        ))}
      </div>
    </ValveSection>
  );
}