import { ValveRecommendations } from '../../types/recommendations';

export function getPulmonaryStenosisRecommendations(
  severity: string,
  rvPressure: number = 0
): ValveRecommendations {
  if (severity === 'Sévère') {
    return {
      treatment: [
        {
          indication: 'Valvuloplastie percutanée',
          class: 'I',
          levelOfEvidence: 'B',
          description: 'Première intention si anatomie favorable'
        },
        {
          indication: 'Chirurgie',
          class: 'I',
          levelOfEvidence: 'C',
          description: 'Si valvuloplastie contre-indiquée ou non réalisable'
        }
      ],
      followUp: [
        'Échocardiographie à 1 mois post-intervention',
        'Suivi à 6 et 12 mois puis annuel',
        'Évaluation de la fonction VD',
        'Test d\'effort selon tolérance'
      ],
      additionalConsiderations: [
        'Évaluation des autres cardiopathies congénitales',
        'Suivi en centre spécialisé',
        'Conseil génétique si nécessaire'
      ]
    };
  }

  return {
    treatment: [
      {
        indication: 'Surveillance',
        class: 'I',
        levelOfEvidence: 'C',
        description: 'Suivi régulier avec évaluation de la progression'
      }
    ],
    followUp: [
      'Échocardiographie annuelle',
      'Test d\'effort si changement symptomatique',
      'Surveillance de la fonction VD'
    ]
  };
}

export function getPulmonaryInsufficiencyRecommendations(
  severity: string,
  hasRVDilation: boolean = false
): ValveRecommendations {
  if (severity === 'Sévère') {
    return {
      treatment: [
        {
          indication: 'Remplacement valvulaire pulmonaire',
          class: 'I',
          levelOfEvidence: 'B',
          description: 'Si dilatation VD significative ou symptômes'
        },
        {
          indication: 'Valve percutanée',
          class: 'IIa',
          levelOfEvidence: 'B',
          description: 'Si anatomie favorable et absence de sténose résiduelle'
        }
      ],
      followUp: [
        'IRM cardiaque annuelle pour volumes VD',
        'Échocardiographie tous les 6 mois',
        'Test d\'effort annuel',
        'Évaluation du remodelage VD'
      ],
      additionalConsiderations: [
        'Timing optimal de l\'intervention',
        'Choix du type de valve',
        'Évaluation des autres lésions associées'
      ]
    };
  }

  return {
    treatment: [
      {
        indication: 'Surveillance',
        class: 'I',
        levelOfEvidence: 'C',
        description: 'Suivi régulier avec évaluation de la progression'
      }
    ],
    followUp: [
      'Échocardiographie annuelle',
      'IRM cardiaque tous les 2-3 ans',
      'Surveillance de la fonction VD'
    ]
  };
}