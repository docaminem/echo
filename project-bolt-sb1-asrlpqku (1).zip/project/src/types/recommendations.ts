export interface TreatmentRecommendation {
  indication: string;
  class: 'I' | 'IIa' | 'IIb' | 'III';
  levelOfEvidence: 'A' | 'B' | 'C';
  description: string;
}

export interface ValveRecommendations {
  treatment: TreatmentRecommendation[];
  followUp: string[];
  additionalConsiderations?: string[];
}