import { ValveData, DiagnosisResult } from '../../types/valve';

export function analyzeAorticStenosis(data: ValveData['aortic']['stenosis']): DiagnosisResult | null {
  if (!data.surface && !data.meanGradient && !data.maxVelocity) return null;

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  // Analyse du type de flux
  let flowPattern = '';
  if (data.surface && data.surface <= 1.0 && data.meanGradient && data.meanGradient < 40) {
    if (data.ejectionFraction !== undefined) {
      if (data.ejectionFraction < 50) {
        flowPattern = 'bas débit/bas gradient classique';
        details.push(`Bas débit/bas gradient classique (FEVG = ${data.ejectionFraction}%)`);
        severity = 'Sévère';
      } else if (data.strokeVolume && data.strokeVolume < 35) {
        flowPattern = 'bas débit/bas gradient paradoxal';
        details.push(`Bas débit/bas gradient paradoxal (VES = ${data.strokeVolume} mL/m²)`);
        severity = 'Sévère';
      } else {
        flowPattern = 'débit normal/bas gradient';
        details.push('Débit normal/bas gradient - Possible sténose modérée');
        severity = 'Modérée';
      }
    }
  }

  // Analyse classique
  if (data.surface) {
    details.push(`Surface valvulaire: ${data.surface} cm²`);
    if (!flowPattern) {
      if (data.surface <= 1.0) severity = 'Sévère';
      else if (data.surface <= 1.5) severity = 'Modérée';
      else if (data.surface < 2.0) severity = 'Légère';
    }
  }

  if (data.meanGradient) {
    details.push(`Gradient moyen: ${data.meanGradient} mmHg`);
    if (!flowPattern && data.meanGradient >= 40) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    }
  }

  if (data.maxVelocity) {
    details.push(`Vitesse maximale: ${data.maxVelocity} m/s`);
    if (!flowPattern && data.maxVelocity >= 4.0) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    }
  }

  // Analyse du test à la dobutamine si disponible
  if (flowPattern === 'bas débit/bas gradient classique' && data.dobutamine) {
    if (data.dobutamine.surface <= 1.0 && data.dobutamine.meanGradient >= 40) {
      details.push('Test à la dobutamine: Sténose aortique vraie avec réserve contractile');
    } else if (data.dobutamine.surface > 1.0) {
      details.push('Test à la dobutamine: Sténose aortique pseudo-sévère');
      severity = 'Modérée';
    }
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Aortique',
    pathology: 'Sténose',
    severity,
    details
  };
}

export function analyzeAorticInsufficiency(data: ValveData['aortic']['insufficiency']): DiagnosisResult | null {
  if (!data.venaContracta && !data.pht && !data.lvotRatio && !data.holodiastolique) return null;

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  if (data.venaContracta) {
    details.push(`Vena contracta: ${data.venaContracta} mm`);
    if (data.venaContracta >= 6) severity = 'Sévère';
    else if (data.venaContracta >= 3) severity = 'Modérée';
    else if (data.venaContracta >= 1) severity = 'Légère';
  }

  if (data.pht) {
    details.push(`PHT: ${data.pht} ms`);
    if (data.pht <= 200) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.pht <= 400) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (data.holodiastolique) {
    details.push('Reflux holodiastolique présent');
    severity = 'Sévère';
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Aortique',
    pathology: 'Insuffisance',
    severity,
    details
  };
}