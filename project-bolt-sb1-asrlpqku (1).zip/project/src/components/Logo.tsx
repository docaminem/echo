import React from 'react';

interface LogoProps {
  className?: string;
}

export function Logo({ className = "w-6 h-6" }: LogoProps) {
  return (
    <img
      src="https://raw.githubusercontent.com/docaminem/test-echo/refs/heads/main/y7fmogyj.png"
      alt="Heart ECG Logo"
      className={className}
    />
  );
}