import { useState, FormEvent } from 'react';
import { ValveData, DiagnosisResult } from '../types/valve';
import { analyzeValveData } from '../utils/diagnosis';

export function useValveForm() {
  const [results, setResults] = useState<DiagnosisResult[]>([]);
  const [showResults, setShowResults] = useState(false);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    const data: ValveData = {
      mitral: {
        stenosis: {
          surface: Number(formData.get('mitralStenosisSurface')),
          meanGradient: Number(formData.get('mitralStenosisMeanGradient')),
          halfTimePressure: Number(formData.get('mitralStenosisHalfTime')),
          papSystolic: Number(formData.get('mitralStenosisPapSystolic'))
        },
        insufficiency: {
          pisa: Number(formData.get('mitralInsufficiencyPisa')),
          ore: Number(formData.get('mitralInsufficiencyOre')),
          regurgitationVolume: Number(formData.get('mitralInsufficiencyVolume')),
          venaContracta: Number(formData.get('mitralInsufficiencyVenaContracta'))
        }
      },
      // ... rest of the valve data structure
    };

    // Clean NaN values
    Object.keys(data).forEach((valve) => {
      Object.keys(data[valve]).forEach((pathology) => {
        Object.keys(data[valve][pathology]).forEach((param) => {
          if (isNaN(data[valve][pathology][param])) {
            delete data[valve][pathology][param];
          }
        });
      });
    });

    const analysisResults = analyzeValveData(data);
    setResults(analysisResults);
    setShowResults(true);
  };

  const resetForm = () => {
    setResults([]);
    setShowResults(false);
  };

  return {
    results,
    showResults,
    handleSubmit,
    resetForm
  };
}