import { DiagnosisResult } from '../../types/valve';
import { ValveRecommendations } from '../../types/recommendations';
import { getAorticStenosisRecommendations } from './aorticRecommendations';
import { getMitralStenosisRecommendations, getMitralInsufficiencyRecommendations } from './mitralRecommendations';
import { getTricuspidStenosisRecommendations, getTricuspidInsufficiencyRecommendations } from './tricuspidRecommendations';
import { getPulmonaryStenosisRecommendations, getPulmonaryInsufficiencyRecommendations } from './pulmonaryRecommendations';

export function getValveRecommendations(result: DiagnosisResult): ValveRecommendations | null {
  switch (result.valve) {
    case 'Aortique':
      if (result.pathology === 'Sténose') {
        return getAorticStenosisRecommendations(result.severity, 50, 75, true);
      } else {
        return getAorticStenosisRecommendations(result.severity, 50);
      }
    case 'Mitrale':
      if (result.pathology === 'Sténose') {
        return getMitralStenosisRecommendations(result.severity);
      } else {
        return getMitralInsufficiencyRecommendations(result.severity, 50);
      }
    case 'Tricuspide':
      if (result.pathology === 'Sténose') {
        return getTricuspidStenosisRecommendations(result.severity);
      } else {
        return getTricuspidInsufficiencyRecommendations(result.severity);
      }
    case 'Pulmonaire':
      if (result.pathology === 'Sténose') {
        return getPulmonaryStenosisRecommendations(result.severity);
      } else {
        return getPulmonaryInsufficiencyRecommendations(result.severity);
      }
    default:
      return null;
  }
}