import React, { useState } from 'react';
import { Heart, FileText, Calculator, Pill } from 'lucide-react';
import { PericarditisCalculator } from './PericarditisCalculator';
import { WorkupGuide } from './WorkupGuide';
import { TreatmentGuide } from './TreatmentGuide';

export function PericarditisSection() {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const sections = [
    {
      id: 'calculator',
      title: 'Calculateur Diagnostic',
      icon: Calculator,
      component: PericarditisCalculator
    },
    {
      id: 'workup',
      title: 'Bilan Initial',
      icon: FileText,
      component: WorkupGuide
    },
    {
      id: 'treatment',
      title: 'Guide Thérapeutique',
      icon: Pill,
      component: TreatmentGuide
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <header className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Heart className="w-6 h-6 text-red-600" />
            Péricardite
          </h1>
          <p className="mt-2 text-gray-600">
            Diagnostic, bilan et traitement de la péricardite aiguë
          </p>
        </header>

        <div className="space-y-4">
          {sections.map(section => (
            <div key={section.id}>
              <button
                onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
                className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                         hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center gap-3">
                  <section.icon className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">{section.title}</span>
                </div>
                <div className="text-blue-600">
                  {activeSection === section.id ? '▼' : '▶'}
                </div>
              </button>
              
              {activeSection === section.id && (
                <div className="mt-4">
                  <section.component />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}