import React, { useState } from 'react';
import { FlaskConical, Calculator } from 'lucide-react';
import { CockroftGaultCalculator } from './CockroftGaultCalculator';
import { HasBledCalculator } from './HasBledCalculator';
import { ChaVascCalculator } from './ChaVascCalculator';
import { PulmonaryEmbolismCalculator } from './PulmonaryEmbolismCalculator';

export function MedicalcSection() {
  const [activeCalculator, setActiveCalculator] = useState<string | null>(null);

  const calculators = [
    {
      id: 'pulmonary-embolism',
      title: 'Calculateur Embolie Pulmonaire',
      component: PulmonaryEmbolismCalculator
    },
    {
      id: 'cockroft',
      title: 'Calculateur DFG Cockroft-Gault',
      component: CockroftGaultCalculator
    },
    {
      id: 'hasbled',
      title: 'Score HAS-BLED',
      component: HasBledCalculator
    },
    {
      id: 'chadsvasc',
      title: 'Score CHA₂DS₂-VASc',
      component: ChaVascCalculator
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <header className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <FlaskConical className="w-6 h-6 text-blue-600" />
            Medicalc
          </h1>
          <p className="mt-2 text-gray-600">
            Calculateurs médicaux utiles en pratique clinique
          </p>
        </header>

        <div className="space-y-4">
          {calculators.map(calc => (
            <div key={calc.id}>
              <button
                onClick={() => setActiveCalculator(activeCalculator === calc.id ? null : calc.id)}
                className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                         hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center gap-3">
                  <Calculator className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">{calc.title}</span>
                </div>
                <div className="text-blue-600">
                  {activeCalculator === calc.id ? '▼' : '▶'}
                </div>
              </button>
              
              {activeCalculator === calc.id && (
                <div className="mt-4">
                  <calc.component />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}