// Update the tricuspid insufficiency interface
export interface ValveData {
  // ... other valve interfaces remain unchanged
  tricuspid: {
    stenosis: {
      surface?: number;
      meanGradient?: number;
    };
    insufficiency: {
      venaContracta?: number;
      pisaRadius?: number;
      ore?: number;
      volume?: number;
      raArea?: number;
      rvDiameter?: number;
      paps?: number;
    };
  };
  // ... rest of the interfaces remain unchanged
}