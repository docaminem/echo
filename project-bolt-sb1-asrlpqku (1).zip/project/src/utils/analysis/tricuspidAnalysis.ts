import { ValveData, DiagnosisResult } from '../../types/valve';

export function analyzeTricuspidStenosis(data: ValveData['tricuspid']['stenosis']): DiagnosisResult | null {
  if (!data.surface && !data.meanGradient) return null;

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  if (data.surface) {
    details.push(`Surface valvulaire: ${data.surface} cm²`);
    if (data.surface <= 1.0) severity = 'Sévère';
    else if (data.surface <= 1.5) severity = 'Modérée';
    else if (data.surface < 2.0) severity = 'Légère';
  }

  if (data.meanGradient) {
    details.push(`Gradient moyen: ${data.meanGradient} mmHg`);
    if (data.meanGradient >= 5) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.meanGradient >= 2) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Tricuspide',
    pathology: 'Sténose',
    severity,
    details
  };
}

export function analyzeTricuspidInsufficiency(data: ValveData['tricuspid']['insufficiency']): DiagnosisResult | null {
  if (!data.venaContracta && !data.pisaRadius && !data.ore && !data.volume && !data.raArea && !data.rvDiameter && !data.paps) {
    return null;
  }

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  // Vena contracta analysis
  if (data.venaContracta) {
    details.push(`Vena contracta: ${data.venaContracta} mm`);
    if (data.venaContracta >= 7) severity = 'Sévère';
    else if (data.venaContracta >= 3) severity = 'Modérée';
    else severity = 'Légère';
  }

  // PISA radius analysis
  if (data.pisaRadius) {
    details.push(`Rayon PISA: ${data.pisaRadius} mm`);
    if (data.pisaRadius > 9) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    }
  }

  // ORE analysis
  if (data.ore) {
    details.push(`Surface de l'orifice régurgitant: ${data.ore} mm²`);
    if (data.ore >= 40) {
      severity = 'Sévère';
    }
  }

  // Regurgitant volume analysis
  if (data.volume) {
    details.push(`Volume régurgitant: ${data.volume} mL/batt`);
    if (data.volume >= 45) {
      severity = 'Sévère';
    }
  }

  // Right atrial area analysis
  if (data.raArea) {
    details.push(`Surface OD: ${data.raArea} cm²`);
    if (data.raArea > 25) {
      details.push('Dilatation sévère de l\'OD');
    }
  }

  // Right ventricle diameter analysis
  if (data.rvDiameter) {
    details.push(`Diamètre VD: ${data.rvDiameter} mm`);
    if (data.rvDiameter > 40) {
      details.push('Dilatation sévère du VD');
    }
  }

  // PAPs analysis
  if (data.paps) {
    details.push(`PAPs: ${data.paps} mmHg`);
    if (data.paps > 50) {
      details.push('HTAP sévère');
    }
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Tricuspide',
    pathology: 'Insuffisance',
    severity,
    details
  };
}