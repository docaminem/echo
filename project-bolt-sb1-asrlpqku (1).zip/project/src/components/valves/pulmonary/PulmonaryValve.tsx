import React, { useState } from 'react';
import { Wind, ArrowDownCircle, ArrowUpCircle } from 'lucide-react';
import { ValveSection } from '../../common/ValveSection';
import { PulmonaryStenosis } from './PulmonaryStenosis';
import { PulmonaryInsufficiency } from './PulmonaryInsufficiency';
import { ClassificationTable } from '../../common/ClassificationTable';
import { pulmonaryStenosisClassification, pulmonaryInsufficiencyClassification } from '../../../data/classifications';

export function PulmonaryValve() {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const sections = [
    {
      id: 'stenosis',
      title: 'Sténose Pulmonaire',
      icon: ArrowDownCircle,
      component: PulmonaryStenosis,
      classification: pulmonaryStenosisClassification
    },
    {
      id: 'insufficiency',
      title: 'Insuffisance Pulmonaire',
      icon: ArrowUpCircle,
      component: PulmonaryInsufficiency,
      classification: pulmonaryInsufficiencyClassification
    }
  ];

  return (
    <ValveSection title="Valve Pulmonaire" icon={Wind}>
      <div className="space-y-4">
        {sections.map(section => (
          <div key={section.id}>
            <button
              onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
              className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                       hover:bg-gray-50 transition-colors duration-200"
            >
              <div className="flex items-center gap-3">
                <section.icon className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-gray-900">{section.title}</span>
              </div>
              <div className="text-blue-600">
                {activeSection === section.id ? '▼' : '▶'}
              </div>
            </button>
            
            {activeSection === section.id && (
              <div className="mt-4 space-y-6">
                <section.component />
                <ClassificationTable {...section.classification} />
              </div>
            )}
          </div>
        ))}
      </div>
    </ValveSection>
  );
}