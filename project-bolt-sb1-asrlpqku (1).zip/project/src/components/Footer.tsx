import React from 'react';

export function Footer() {
  return (
    <footer className="bg-white border-t mt-auto py-4">
      <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-600">
        Copyright © {new Date().getFullYear()} Dr K.Amine - Tous droits réservés
      </div>
    </footer>
  );
}