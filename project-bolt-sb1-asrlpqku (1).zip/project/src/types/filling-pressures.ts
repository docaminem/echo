export interface FillingPressuresMeasurements {
  waveE: number;
  waveA?: number;
  decelerationTime: number;
  septalEa: number;
  lateralEa: number;
  preservedEF: boolean;
  paps?: number;
  leftAtrialVolume?: number;
  hasAtrialFibrillation: boolean;
}

export interface FillingPressuresCalculations {
  eToAverageTdRatio: number;
  eToARatio?: number;
  averageEa: number;
  leftAtrialVolumeIndex?: number;
}

export interface FillingPressuresInterpretation {
  conclusion: string;
  details: string;
  color: string;
  additionalFindings?: string[];
}

export interface FillingPressuresData {
  measurements: FillingPressuresMeasurements;
  calculations: FillingPressuresCalculations;
  interpretation: FillingPressuresInterpretation;
}