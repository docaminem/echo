import { ValveData, DiagnosisResult } from '../types/valve';
import { analyzeMitralStenosis, analyzeMitralInsufficiency } from './analysis/mitralAnalysis';
import { analyzeAorticStenosis, analyzeAorticInsufficiency } from './analysis/aorticAnalysis';
import { analyzeTricuspidStenosis, analyzeTricuspidInsufficiency } from './analysis/tricuspidAnalysis';
import { analyzePulmonaryStenosis, analyzePulmonaryInsufficiency } from './analysis/pulmonaryAnalysis';

export function analyzeValveData(data: ValveData): DiagnosisResult[] {
  const results: DiagnosisResult[] = [];

  // Analyse de la valve mitrale
  const mitralStenosis = analyzeMitralStenosis(data.mitral.stenosis);
  if (mitralStenosis) results.push(mitralStenosis);

  const mitralInsufficiency = analyzeMitralInsufficiency(data.mitral.insufficiency);
  if (mitralInsufficiency) results.push(mitralInsufficiency);

  // Analyse de la valve aortique
  const aorticStenosis = analyzeAorticStenosis(data.aortic.stenosis);
  if (aorticStenosis) results.push(aorticStenosis);

  const aorticInsufficiency = analyzeAorticInsufficiency(data.aortic.insufficiency);
  if (aorticInsufficiency) results.push(aorticInsufficiency);

  // Analyse de la valve tricuspide
  const tricuspidStenosis = analyzeTricuspidStenosis(data.tricuspid.stenosis);
  if (tricuspidStenosis) results.push(tricuspidStenosis);

  const tricuspidInsufficiency = analyzeTricuspidInsufficiency(data.tricuspid.insufficiency);
  if (tricuspidInsufficiency) results.push(tricuspidInsufficiency);

  // Analyse de la valve pulmonaire
  const pulmonaryStenosis = analyzePulmonaryStenosis(data.pulmonary.stenosis);
  if (pulmonaryStenosis) results.push(pulmonaryStenosis);

  const pulmonaryInsufficiency = analyzePulmonaryInsufficiency(data.pulmonary.insufficiency);
  if (pulmonaryInsufficiency) results.push(pulmonaryInsufficiency);

  return results;
}