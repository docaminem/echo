import React, { useState, useRef } from 'react';
import { ValveTabs } from './ValveTabs';
import { MitralValve } from './valves/mitral/MitralValve';
import { AorticValve } from './valves/aortic/AorticValve';
import { TricuspidValve } from './valves/tricuspid/TricuspidValve';
import { PulmonaryValve } from './valves/pulmonary/PulmonaryValve';
import { DiagnosisResults } from './DiagnosisResult';
import { ValveData, DiagnosisResult } from '../types/valve';
import { analyzeValveData } from '../utils/diagnosis';
import { RotateCcw } from 'lucide-react';

export function PatientForm() {
  const [activeValve, setActiveValve] = useState('mitral');
  const [diagnosisResults, setDiagnosisResults] = useState<DiagnosisResult[]>([]);
  const [showResults, setShowResults] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    const data: ValveData = {
      mitral: {
        stenosis: {
          surface: Number(formData.get('mitralStenosisSurface')),
          meanGradient: Number(formData.get('mitralStenosisMeanGradient')),
          halfTimePressure: Number(formData.get('mitralStenosisHalfTime')),
          papSystolic: Number(formData.get('mitralStenosisPapSystolic'))
        },
        insufficiency: {
          pisa: Number(formData.get('mitralInsufficiencyPisa')),
          ore: Number(formData.get('mitralInsufficiencyOre')),
          regurgitationVolume: Number(formData.get('mitralInsufficiencyVolume')),
          venaContracta: Number(formData.get('mitralInsufficiencyVenaContracta'))
        }
      },
      aortic: {
        stenosis: {
          surface: Number(formData.get('aorticStenosisSurface')),
          meanGradient: Number(formData.get('aorticStenosisMeanGradient')),
          maxVelocity: Number(formData.get('aorticStenosisMaxVelocity')),
          ejectionFraction: Number(formData.get('aorticStenosisEjectionFraction')),
          strokeVolume: Number(formData.get('aorticStenosisStrokeVolume'))
        },
        insufficiency: {
          venaContracta: Number(formData.get('aorticInsufficiencyVenaContracta')),
          pht: Number(formData.get('aorticInsufficiencyPht')),
          lvotRatio: Number(formData.get('aorticInsufficiencyLvotRatio')),
          holodiastolique: Boolean(formData.get('aorticInsufficiencyHolodiastolique'))
        }
      },
      tricuspid: {
        stenosis: {
          surface: Number(formData.get('tricuspidStenosisSurface')),
          meanGradient: Number(formData.get('tricuspidStenosisMeanGradient'))
        },
        insufficiency: {
          venaContracta: Number(formData.get('tricuspidInsufficiencyVenaContracta')),
          pisaRadius: Number(formData.get('tricuspidInsufficiencyPisaRadius')),
          ore: Number(formData.get('tricuspidInsufficiencyOre')),
          volume: Number(formData.get('tricuspidInsufficiencyVolume')),
          raArea: Number(formData.get('tricuspidInsufficiencyRaArea')),
          rvDiameter: Number(formData.get('tricuspidInsufficiencyRvDiameter')),
          paps: Number(formData.get('tricuspidInsufficiencyPaps'))
        }
      },
      pulmonary: {
        stenosis: {
          meanGradient: Number(formData.get('pulmonaryStenosisMeanGradient')),
          maxVelocity: Number(formData.get('pulmonaryStenosisMaxVelocity'))
        },
        insufficiency: {
          venaContracta: Number(formData.get('pulmonaryInsufficiencyVenaContracta')),
          pht: Number(formData.get('pulmonaryInsufficiencyPht'))
        }
      }
    };

    // Clean NaN values
    Object.keys(data).forEach((valve) => {
      Object.keys(data[valve]).forEach((pathology) => {
        Object.keys(data[valve][pathology]).forEach((param) => {
          if (isNaN(data[valve][pathology][param])) {
            delete data[valve][pathology][param];
          }
        });
      });
    });

    const results = analyzeValveData(data);
    setDiagnosisResults(results);
    setShowResults(true);
  };

  const handleReset = () => {
    formRef.current?.reset();
    setDiagnosisResults([]);
    setShowResults(false);
  };

  const renderActiveValve = () => {
    switch (activeValve) {
      case 'mitral':
        return <MitralValve />;
      case 'aortic':
        return <AorticValve />;
      case 'tricuspid':
        return <TricuspidValve />;
      case 'pulmonary':
        return <PulmonaryValve />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <ValveTabs activeValve={activeValve} onValveChange={setActiveValve} />
      
      <form ref={formRef} onSubmit={handleSubmit} className="space-y-8">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          {renderActiveValve()}
        </div>

        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={handleReset}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Réinitialiser
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Analyser
          </button>
        </div>
      </form>

      {showResults && (
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Résultats de l'analyse</h2>
          <DiagnosisResults results={diagnosisResults} />
        </div>
      )}
    </div>
  );
}