import React from 'react';
import { Heart, Activity, Waves, Wind } from 'lucide-react';
import { cn } from '../lib/utils';

interface ValveTabsProps {
  activeValve: string;
  onValveChange: (valve: string) => void;
}

export function ValveTabs({ activeValve, onValveChange }: ValveTabsProps) {
  const tabs = [
    { id: 'mitral', label: 'Mitrale', icon: Heart },
    { id: 'aortic', label: 'Aortique', icon: Activity },
    { id: 'tricuspid', label: 'Tricuspide', icon: Waves },
    { id: 'pulmonary', label: 'Pulmonaire', icon: Wind },
  ];

  return (
    <div className="border-b border-gray-200 overflow-x-auto">
      <nav className="flex min-w-full md:min-w-0 px-2 md:px-0" aria-label="Valves">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => onValveChange(id)}
            className={cn(
              'flex items-center gap-1 md:gap-2 px-3 md:px-4 py-2 text-sm font-medium border-b-2 -mb-px whitespace-nowrap flex-1 justify-center',
              activeValve === id
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            )}
          >
            <Icon className="hidden md:block w-4 h-4" />
            <span>{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}