import React, { useState } from 'react';
import { Calculator } from 'lucide-react';
import { FormField } from '../common/FormField';

export function PapsCalculator() {
  const [values, setValues] = useState({
    trVelocity: '',
    ivcDiameter: '',
    ivcCollapsibility: '',
  });

  const [paps, setPaps] = useState<number | null>(null);

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  const calculateRAP = (diameter: number, collapsibility: number): number => {
    if (diameter < 2.1 && collapsibility > 50) return 3;
    if (diameter >= 2.1 && collapsibility <= 50) return 15;
    return 8;
  };

  const calculatePAPS = () => {
    const velocity = Number(values.trVelocity);
    const diameter = Number(values.ivcDiameter);
    const collapsibility = Number(values.ivcCollapsibility);

    if (!velocity || !diameter || !collapsibility) {
      setPaps(null);
      return;
    }

    const rap = calculateRAP(diameter, collapsibility);
    const calculatedPaps = Math.round(4 * (velocity * velocity) + rap);
    setPaps(calculatedPaps);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Calculator className="w-5 h-5 text-blue-600" />
        Calculateur PAPS
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          label="Vitesse maximale IT"
          name="trVelocity"
          value={values.trVelocity}
          onChange={handleChange('trVelocity')}
          description="Vitesse maximale de l'insuffisance tricuspide en m/s"
          placeholder="Ex: 2.8"
          required
        />
        
        <FormField
          label="Diamètre VCI"
          name="ivcDiameter"
          value={values.ivcDiameter}
          onChange={handleChange('ivcDiameter')}
          description="Diamètre de la veine cave inférieure en cm"
          placeholder="Ex: 1.8"
          required
        />
        
        <FormField
          label="Collapsibilité VCI"
          name="ivcCollapsibility"
          value={values.ivcCollapsibility}
          onChange={handleChange('ivcCollapsibility')}
          description="Pourcentage de collapsibilité respiratoire"
          placeholder="Ex: 50"
          required
        />
      </div>

      <div className="mt-6 flex flex-col md:flex-row justify-between items-center gap-4">
        <button
          onClick={calculatePAPS}
          className="w-full md:w-auto px-6 py-3 bg-blue-600 text-white font-medium rounded-lg 
                   hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 
                   focus:ring-offset-2 transition-colors duration-200"
        >
          Calculer
        </button>
        
        {paps !== null && (
          <div className="text-center md:text-right">
            <div className="text-2xl font-bold text-blue-900">
              PAPS = {paps} mmHg
            </div>
            <div className="text-sm font-medium mt-1">
              {paps > 50 ? 'HTAP sévère' : 
               paps > 35 ? 'HTAP modérée' : 
               paps > 25 ? 'HTAP légère' : 'PAPS normale'}
            </div>
          </div>
        )}
      </div>

      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <p className="text-sm font-medium text-gray-900 mb-2">Formule: PAPS = 4 × (VIT)² + PRA</p>
        <p className="text-sm text-gray-600 mb-2">PRA estimée selon diamètre et collapsibilité VCI:</p>
        <ul className="text-sm text-gray-600 list-disc list-inside space-y-1">
          <li>3 mmHg si VCI inférieure ou égale à 2.1 cm et collapsibilité supérieure à 50%</li>
          <li>15 mmHg si VCI supérieure à 2.1 cm et collapsibilité inférieure ou égale à 50%</li>
          <li>8 mmHg dans les autres cas</li>
        </ul>
      </div>
    </div>
  );
}