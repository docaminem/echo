import React, { useState } from 'react';
import { ArrowDownCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function AorticStenosis() {
  const [values, setValues] = useState({
    surface: '',
    meanGradient: '',
    maxVelocity: '',
    ejectionFraction: '',
    strokeVolume: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-orange-700">
        <ArrowDownCircle className="w-4 h-4" />
        Sténose Aortique
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="Surface Valve"
          name="aorticStenosisSurface"
          value={values.surface}
          onChange={handleChange('surface')}
          description="Surface valvulaire aortique en cm²"
          placeholder="Ex: 1.2"
        />
        
        <FormField
          label="Gradient Moyen"
          name="aorticStenosisMeanGradient"
          value={values.meanGradient}
          onChange={handleChange('meanGradient')}
          description="Gradient moyen transaortique en mmHg"
          placeholder="Ex: 40"
        />
        
        <FormField
          label="Vitesse Max"
          name="aorticStenosisMaxVelocity"
          value={values.maxVelocity}
          onChange={handleChange('maxVelocity')}
          description="Vitesse maximale transaortique en m/s"
          placeholder="Ex: 4.0"
        />
        
        <FormField
          label="Fraction d'Éjection"
          name="aorticStenosisEjectionFraction"
          value={values.ejectionFraction}
          onChange={handleChange('ejectionFraction')}
          description="FEVG en pourcentage"
          placeholder="Ex: 55"
        />
        
        <FormField
          label="Volume d'Éjection"
          name="aorticStenosisStrokeVolume"
          value={values.strokeVolume}
          onChange={handleChange('strokeVolume')}
          description="Volume d'éjection systolique indexé en mL/m²"
          placeholder="Ex: 45"
        />
      </div>
    </div>
  );
}