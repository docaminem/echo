import { ValveRecommendations } from '../../types/recommendations';

export function getTricuspidStenosisRecommendations(
  severity: string,
  hasAtrialFibrillation: boolean = false
): ValveRecommendations {
  if (severity === 'Sévère') {
    return {
      treatment: [
        {
          indication: 'Sténose tricuspide sévère symptomatique',
          class: 'I',
          levelOfEvidence: 'C',
          description: 'Remplacement valvulaire tricuspide'
        },
        {
          indication: 'Anticoagulation',
          class: 'I',
          levelOfEvidence: 'C',
          description: 'Si fibrillation atriale associée'
        }
      ],
      followUp: [
        'Échocardiographie à 1 mois post-chirurgie',
        'Suivi à 3, 6 et 12 mois puis annuel',
        'Surveillance de l\'anticoagulation',
        'Évaluation de la fonction VD'
      ],
      additionalConsiderations: [
        'Évaluation de l\'HTAP',
        'Optimisation de la volémie',
        'Traitement des comorbidités'
      ]
    };
  }

  return {
    treatment: [
      {
        indication: 'Surveillance',
        class: 'I',
        levelOfEvidence: 'C',
        description: 'Suivi clinique et échographique régulier'
      }
    ],
    followUp: [
      'Échocardiographie annuelle',
      'Surveillance des symptômes',
      'Contrôle du rythme si FA'
    ]
  };
}

export function getTricuspidInsufficiencyRecommendations(
  severity: string,
  paps: number = 0,
  hasRightHeartFailure: boolean = false
): ValveRecommendations {
  if (severity === 'Sévère') {
    return {
      treatment: [
        {
          indication: 'Plastie tricuspide',
          class: 'I',
          levelOfEvidence: 'B',
          description: 'Lors d\'une chirurgie mitrale ou aortique concomitante'
        },
        {
          indication: 'Chirurgie isolée',
          class: 'IIa',
          levelOfEvidence: 'C',
          description: 'Si IT sévère symptomatique sans dysfonction VD sévère'
        }
      ],
      followUp: [
        'Échocardiographie tous les 3-6 mois',
        'Évaluation de la fonction VD',
        'Surveillance des signes d\'insuffisance cardiaque droite',
        'Optimisation du traitement médical'
      ],
      additionalConsiderations: [
        'Traitement de l\'HTAP sous-jacente',
        'Évaluation du timing chirurgical optimal',
        'Considération pour intervention précoce si dilatation annulaire progressive'
      ]
    };
  }

  return {
    treatment: [
      {
        indication: 'Surveillance',
        class: 'I',
        levelOfEvidence: 'C',
        description: 'Suivi régulier avec évaluation de la progression'
      }
    ],
    followUp: [
      'Échocardiographie annuelle si modérée',
      'Échocardiographie tous les 2 ans si légère',
      'Surveillance de la pression pulmonaire'
    ]
  };
}