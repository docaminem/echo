import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ValveSectionProps {
  title: string;
  icon: LucideIcon;
  children: React.ReactNode;
}

export function ValveSection({ title, icon: Icon, children }: ValveSectionProps) {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium flex items-center gap-2 border-b pb-2">
        <Icon className="w-5 h-5" />
        {title}
      </h3>
      <div className="space-y-6">
        {children}
      </div>
    </div>
  );
}