import React, { useState } from 'react';
import { ArrowUpCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function TricuspidInsufficiency() {
  const [values, setValues] = useState({
    venaContracta: '',
    pisaRadius: '',
    ore: '',
    volume: '',
    raArea: '',
    rvDiameter: '',
    paps: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-red-700">
        <ArrowUpCircle className="w-4 h-4" />
        Insuffisance Tricuspide
      </h4>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="Vena Contracta"
          name="tricuspidInsufficiencyVenaContracta"
          value={values.venaContracta}
          onChange={handleChange('venaContracta')}
          description="Largeur de la vena contracta en mm"
          placeholder="Ex: 6"
          step="0.1"
        />
        <FormField
          label="Rayon PISA"
          name="tricuspidInsufficiencyPisaRadius"
          value={values.pisaRadius}
          onChange={handleChange('pisaRadius')}
          description="Rayon de la zone de convergence PISA en mm"
          placeholder="Ex: 7"
          step="0.1"
        />
        <FormField
          label="Surface de l'orifice régurgitant"
          name="tricuspidInsufficiencyOre"
          value={values.ore}
          onChange={handleChange('ore')}
          description="Surface de l'orifice régurgitant en mm²"
          placeholder="Ex: 35"
          step="1"
        />
        <FormField
          label="Volume régurgitant"
          name="tricuspidInsufficiencyVolume"
          value={values.volume}
          onChange={handleChange('volume')}
          description="Volume régurgité en mL/battement"
          placeholder="Ex: 40"
          step="1"
        />
        <FormField
          label="Surface OD"
          name="tricuspidInsufficiencyRaArea"
          value={values.raArea}
          onChange={handleChange('raArea')}
          description="Surface de l'oreillette droite en cm²"
          placeholder="Ex: 22"
          step="0.1"
        />
        <FormField
          label="Diamètre VD"
          name="tricuspidInsufficiencyRvDiameter"
          value={values.rvDiameter}
          onChange={handleChange('rvDiameter')}
          description="Diamètre du ventricule droit en mm"
          placeholder="Ex: 35"
          step="1"
        />
        <FormField
          label="PAPs"
          name="tricuspidInsufficiencyPaps"
          value={values.paps}
          onChange={handleChange('paps')}
          description="Pression artérielle pulmonaire systolique en mmHg"
          placeholder="Ex: 40"
          step="1"
        />
      </div>
    </div>
  );
}