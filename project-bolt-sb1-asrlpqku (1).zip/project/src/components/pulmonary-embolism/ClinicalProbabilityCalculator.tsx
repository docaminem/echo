import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

interface ClinicalSign {
  id: string;
  label: string;
  points: number;
  category: 'wells' | 'geneva';
}

const wellsCriteria: ClinicalSign[] = [
  { id: 'dvt_symptoms', label: 'Signes cliniques de TVP', points: 3, category: 'wells' },
  { id: 'pe_likely', label: 'EP comme diagnostic le plus probable', points: 3, category: 'wells' },
  { id: 'tachycardia', label: 'Fréquence cardiaque > 100/min', points: 1.5, category: 'wells' },
  { id: 'immobilization', label: 'Immobilisation ou chirurgie < 4 semaines', points: 1.5, category: 'wells' },
  { id: 'previous_dvt', label: 'Antécédent de TVP ou EP', points: 1.5, category: 'wells' },
  { id: 'hemoptysis', label: 'Hémoptysie', points: 1, category: 'wells' },
  { id: 'cancer', label: 'Cancer actif', points: 1, category: 'wells' }
];

const genevaCriteria: ClinicalSign[] = [
  { id: 'age_65', label: 'Âge > 65 ans', points: 1, category: 'geneva' },
  { id: 'previous_dvt_pe', label: 'Antécédent de TVP ou EP', points: 3, category: 'geneva' },
  { id: 'surgery', label: 'Chirurgie ou fracture < 1 mois', points: 2, category: 'geneva' },
  { id: 'active_cancer', label: 'Cancer actif', points: 2, category: 'geneva' },
  { id: 'unilateral_pain', label: 'Douleur unilatérale membre inférieur', points: 3, category: 'geneva' },
  { id: 'hemoptysis', label: 'Hémoptysie', points: 2, category: 'geneva' },
  { id: 'heart_rate_75', label: 'Fréquence cardiaque 75-94/min', points: 3, category: 'geneva' },
  { id: 'heart_rate_95', label: 'Fréquence cardiaque ≥ 95/min', points: 5, category: 'geneva' },
  { id: 'pain_palpation', label: 'Douleur à la palpation/Œdème unilatéral', points: 4, category: 'geneva' }
];

export function ClinicalProbabilityCalculator() {
  const [selectedScore, setSelectedScore] = useState<'wells' | 'geneva'>('wells');
  const [selectedSigns, setSelectedSigns] = useState<string[]>([]);
  
  const toggleSign = (id: string) => {
    setSelectedSigns(prev => 
      prev.includes(id) 
        ? prev.filter(s => s !== id)
        : [...prev, id]
    );
  };

  const currentCriteria = selectedScore === 'wells' ? wellsCriteria : genevaCriteria;
  
  const score = selectedSigns.reduce((total, id) => {
    const sign = currentCriteria.find(s => s.id === id);
    return total + (sign?.points || 0);
  }, 0);

  const getInterpretation = () => {
    if (selectedScore === 'wells') {
      if (score > 6) return { text: 'Probabilité forte', color: 'text-red-600' };
      if (score > 2) return { text: 'Probabilité intermédiaire', color: 'text-orange-600' };
      return { text: 'Probabilité faible', color: 'text-green-600' };
    } else {
      if (score > 10) return { text: 'Probabilité forte', color: 'text-red-600' };
      if (score > 4) return { text: 'Probabilité intermédiaire', color: 'text-orange-600' };
      return { text: 'Probabilité faible', color: 'text-green-600' };
    }
  };

  const interpretation = getInterpretation();

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Calculator className="w-5 h-5 text-blue-600" />
        Calculateur de Probabilité Clinique
      </h2>

      <div className="flex gap-4 mb-6">
        <button
          onClick={() => {
            setSelectedScore('wells');
            setSelectedSigns([]);
          }}
          className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors
            ${selectedScore === 'wells' 
              ? 'bg-blue-100 text-blue-700' 
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
        >
          Score de Wells
        </button>
        <button
          onClick={() => {
            setSelectedScore('geneva');
            setSelectedSigns([]);
          }}
          className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors
            ${selectedScore === 'geneva' 
              ? 'bg-blue-100 text-blue-700' 
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
        >
          Score de Genève
        </button>
      </div>

      <div className="space-y-3">
        {currentCriteria.map(sign => (
          <label 
            key={sign.id}
            className="flex items-center gap-3 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer"
          >
            <input
              type="checkbox"
              checked={selectedSigns.includes(sign.id)}
              onChange={() => toggleSign(sign.id)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="flex-1">{sign.label}</span>
            <span className="text-sm text-gray-500">
              {sign.points} {sign.points > 1 ? 'points' : 'point'}
            </span>
          </label>
        ))}

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium">Score total:</span>
            <span className="text-lg font-bold">{score} points</span>
          </div>
          <p className={`font-medium ${interpretation.color}`}>
            {interpretation.text}
          </p>
        </div>
      </div>
    </div>
  );
}