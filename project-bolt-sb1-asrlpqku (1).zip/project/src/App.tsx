import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Calculator, Heart, Sun as Lung, FlaskConical } from 'lucide-react';
import { Logo } from './components/Logo';
import { PatientForm } from './components/PatientForm';
import { FillingPressuresCalculator } from './components/filling-pressures/FillingPressuresCalculator';
import { PericarditisSection } from './components/pericarditis/PericarditisSection';
import { PulmonaryEmbolismSection } from './components/pulmonary-embolism/PulmonaryEmbolismSection';
import { MedicalcSection } from './components/medicalc/MedicalcSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 md:py-6">
          <nav className="flex flex-col md:flex-row md:items-center gap-4 md:gap-8">
            <Link to="/" className="flex items-center gap-3 text-gray-900 hover:text-gray-600">
              <Logo className="w-12 md:w-14 h-12 md:h-14" />
              <h1 className="text-lg md:text-2xl font-bold">
                CardioDiag
              </h1>
            </Link>
            <Link 
              to="/filling-pressures" 
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm md:text-base"
            >
              <Calculator className="w-4 md:w-5 h-4 md:h-5" />
              <span>Pressions de Remplissage</span>
            </Link>
            <Link 
              to="/pericarditis" 
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm md:text-base"
            >
              <Heart className="w-4 md:w-5 h-4 md:h-5" />
              <span>Péricardite</span>
            </Link>
            <Link 
              to="/pulmonary-embolism" 
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm md:text-base"
            >
              <Lung className="w-4 md:w-5 h-4 md:h-5" />
              <span>Embolie Pulmonaire</span>
            </Link>
            <Link 
              to="/medicalc" 
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 text-sm md:text-base"
            >
              <FlaskConical className="w-4 md:w-5 h-4 md:h-5" />
              <span>Medicalc</span>
            </Link>
          </nav>
        </div>
      </header>

      <Routes>
        <Route path="/" element={
          <main className="max-w-7xl mx-auto px-4 py-6 md:py-8 flex-1">
            <div className="bg-white shadow rounded-lg">
              <PatientForm />
            </div>
          </main>
        } />
        <Route path="/filling-pressures" element={<FillingPressuresCalculator />} />
        <Route path="/pericarditis" element={<PericarditisSection />} />
        <Route path="/pulmonary-embolism" element={<PulmonaryEmbolismSection />} />
        <Route path="/medicalc" element={<MedicalcSection />} />
      </Routes>

      <Footer />
    </div>
  );
}