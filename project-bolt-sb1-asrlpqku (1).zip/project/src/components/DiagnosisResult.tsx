import React from 'react';
import { AlertCircle } from 'lucide-react';
import { DiagnosisResult } from '../types/valve';
import { getValveRecommendations } from '../utils/recommendations';

const severityColors = {
  'Légère': 'text-yellow-600',
  'Modérée': 'text-orange-600',
  'Sévère': 'text-red-600',
  'Normal': 'text-green-600'
};

interface DiagnosisResultsProps {
  results: DiagnosisResult[];
}

export function DiagnosisResults({ results }: DiagnosisResultsProps) {
  if (results.length === 0) {
    return (
      <div className="bg-gray-50 p-4 rounded-lg text-center text-gray-500">
        Aucune pathologie significative détectée
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {results.map((result, index) => {
        const recommendations = getValveRecommendations(result);
        
        return (
          <div key={index} className="bg-white p-4 rounded-lg shadow-sm">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <AlertCircle className="w-5 h-5" />
              <h4 className="font-medium text-sm md:text-base">
                {result.valve} - {result.pathology}
              </h4>
              <span className={`ml-auto font-medium ${severityColors[result.severity]}`}>
                {result.severity}
              </span>
            </div>
            
            <ul className="list-disc list-inside text-xs md:text-sm text-gray-600 space-y-1 mb-4">
              {result.details.map((detail, i) => (
                <li key={i}>{detail}</li>
              ))}
            </ul>

            {recommendations && (
              <div className="mt-4 border-t pt-4">
                <h5 className="font-medium mb-2 text-sm md:text-base">Recommandations</h5>
                <div className="space-y-4">
                  {recommendations.treatment.map((rec, i) => (
                    <div key={i} className="bg-gray-50 p-3 rounded text-xs md:text-sm">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                        <span className="font-medium">{rec.indication}</span>
                        <span className="text-gray-500">
                          Classe {rec.class} - Niveau {rec.levelOfEvidence}
                        </span>
                      </div>
                      <p className="text-gray-600">{rec.description}</p>
                    </div>
                  ))}
                  
                  {recommendations.followUp.length > 0 && (
                    <div className="mt-3">
                      <h6 className="font-medium mb-2 text-sm">Suivi</h6>
                      <ul className="list-disc list-inside text-xs md:text-sm text-gray-600">
                        {recommendations.followUp.map((item, i) => (
                          <li key={i}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}