import React, { useState } from 'react';
import { ArrowUpCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function PulmonaryInsufficiency() {
  const [values, setValues] = useState({
    venaContracta: '',
    pht: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-red-700">
        <ArrowUpCircle className="w-4 h-4" />
        Insuffisance Pulmonaire
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="Vena Contracta"
          name="pulmonaryInsufficiencyVenaContracta"
          value={values.venaContracta}
          onChange={handleChange('venaContracta')}
          description="Largeur de la vena contracta en mm"
          placeholder="Ex: 4"
        />
        
        <FormField
          label="PHT"
          name="pulmonaryInsufficiencyPht"
          value={values.pht}
          onChange={handleChange('pht')}
          description="Temps de demi-décroissance en ms"
          placeholder="Ex: 150"
        />
      </div>
    </div>
  );
}