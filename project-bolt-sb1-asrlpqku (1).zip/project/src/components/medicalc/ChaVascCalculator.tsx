import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

interface RiskFactor {
  id: string;
  label: string;
  description: string;
  points: number;
}

const riskFactors: RiskFactor[] = [
  {
    id: 'chf',
    label: 'Insuffisance cardiaque',
    description: 'Signes/symptômes d\'IC ou FEVG réduite',
    points: 1
  },
  {
    id: 'hypertension',
    label: 'Hypertension',
    description: 'HTA traitée ou non contrôlée',
    points: 1
  },
  {
    id: 'age75',
    label: 'Âge ≥ 75 ans',
    description: 'Âge supérieur ou égal à 75 ans',
    points: 2
  },
  {
    id: 'diabetes',
    label: 'Diabète',
    description: 'Diabète traité',
    points: 1
  },
  {
    id: 'stroke',
    label: 'AVC/AIT/Embolie',
    description: 'Antécédent d\'AVC, AIT ou embolie périphérique',
    points: 2
  },
  {
    id: 'vascular',
    label: 'Maladie vasculaire',
    description: 'IDM, AOMI ou plaque aortique',
    points: 1
  },
  {
    id: 'age65',
    label: 'Âge 65-74 ans',
    description: 'Âge entre 65 et 74 ans',
    points: 1
  },
  {
    id: 'female',
    label: 'Sexe féminin',
    description: 'Genre féminin',
    points: 1
  }
];

export function ChaVascCalculator() {
  const [selectedFactors, setSelectedFactors] = useState<string[]>([]);

  const toggleFactor = (id: string) => {
    // Désélectionner age65 si age75 est sélectionné et vice versa
    if (id === 'age75' && selectedFactors.includes('age65')) {
      setSelectedFactors(prev => 
        prev.includes(id) 
          ? prev.filter(f => f !== id)
          : [...prev.filter(f => f !== 'age65'), id]
      );
    } else if (id === 'age65' && selectedFactors.includes('age75')) {
      setSelectedFactors(prev => 
        prev.includes(id) 
          ? prev.filter(f => f !== id)
          : [...prev.filter(f => f !== 'age75'), id]
      );
    } else {
      setSelectedFactors(prev => 
        prev.includes(id) 
          ? prev.filter(f => f !== id)
          : [...prev, id]
      );
    }
  };

  const score = selectedFactors.reduce((total, id) => {
    const factor = riskFactors.find(f => f.id === id);
    return total + (factor?.points || 0);
  }, 0);

  const getRecommendation = (score: number) => {
    if (score === 0) {
      return {
        risk: 'Risque faible',
        recommendation: 'Pas d\'anticoagulation recommandée',
        color: 'text-green-600'
      };
    }
    if (score === 1) {
      return {
        risk: 'Risque intermédiaire',
        recommendation: 'Anticoagulation à considérer',
        color: 'text-yellow-600'
      };
    }
    return {
      risk: 'Risque élevé',
      recommendation: 'Anticoagulation recommandée',
      color: 'text-red-600'
    };
  };

  const recommendation = getRecommendation(score);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Calculator className="w-5 h-5 text-blue-600" />
        Score CHA₂DS₂-VASc
      </h2>

      <div className="space-y-4">
        {riskFactors.map(factor => (
          <label 
            key={factor.id}
            className="flex items-center gap-3 p-4 rounded-lg border hover:bg-gray-50 cursor-pointer"
          >
            <input
              type="checkbox"
              checked={selectedFactors.includes(factor.id)}
              onChange={() => toggleFactor(factor.id)}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <div className="flex-1">
              <div className="font-medium text-gray-900">{factor.label}</div>
              <div className="text-sm text-gray-500">{factor.description}</div>
            </div>
            <div className="text-sm font-medium text-gray-500">
              {factor.points} {factor.points > 1 ? 'points' : 'point'}
            </div>
          </label>
        ))}

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium text-gray-900">Score total:</span>
            <span className="text-2xl font-bold text-blue-900">{score} points</span>
          </div>
          <div className={`font-medium ${recommendation.color}`}>
            {recommendation.risk}
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {recommendation.recommendation}
          </p>
        </div>
      </div>
    </div>
  );
}