import React from 'react';

interface ClassificationRow {
  severity: 'Légère' | 'Modérée' | 'Sévère';
  criteria: string[];
}

interface ClassificationTableProps {
  title: string;
  headers: string[];
  rows: ClassificationRow[];
}

export function ClassificationTable({ title, headers, rows }: ClassificationTableProps) {
  const severityColors = {
    'Légère': 'bg-yellow-50 text-yellow-700',
    'Modérée': 'bg-orange-50 text-orange-700',
    'Sévère': 'bg-red-50 text-red-700'
  };

  return (
    <div className="mb-6">
      <h4 className="text-sm font-medium text-gray-700 mb-2">{title}</h4>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 border rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              {headers.map((header, index) => (
                <th
                  key={index}
                  className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {rows.map((row, index) => (
              <tr key={index}>
                <td className={`px-4 py-2 whitespace-nowrap text-sm font-medium ${severityColors[row.severity]}`}>
                  {row.severity}
                </td>
                {row.criteria.map((criterion, idx) => (
                  <td key={idx} className="px-4 py-2 text-sm text-gray-500">
                    {criterion}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}