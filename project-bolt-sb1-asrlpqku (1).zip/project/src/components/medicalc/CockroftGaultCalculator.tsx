import React, { useState } from 'react';
import { Calculator } from 'lucide-react';
import { FormField } from '../common/FormField';

export function CockroftGaultCalculator() {
  const [values, setValues] = useState({
    age: '',
    weight: '',
    creatinine: '',
    gender: 'male'
  });

  const [dfg, setDfg] = useState<number | null>(null);

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  const calculateDFG = () => {
    const age = Number(values.age);
    const weight = Number(values.weight);
    const creatinine = Number(values.creatinine);

    if (!age || !weight || !creatinine) {
      setDfg(null);
      return;
    }

    const genderFactor = values.gender === 'male' ? 1 : 0.85;
    const calculatedDfg = ((140 - age) * weight * genderFactor) / (creatinine * 0.814);
    setDfg(Math.round(calculatedDfg * 10) / 10);
  };

  const getStage = (dfg: number) => {
    if (dfg >= 90) return { stage: 'DFG normal ou augmenté', color: 'text-green-600' };
    if (dfg >= 60) return { stage: 'Insuffisance rénale légère', color: 'text-yellow-600' };
    if (dfg >= 30) return { stage: 'Insuffisance rénale modérée', color: 'text-orange-600' };
    if (dfg >= 15) return { stage: 'Insuffisance rénale sévère', color: 'text-red-600' };
    return { stage: 'Insuffisance rénale terminale', color: 'text-red-900' };
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Calculator className="w-5 h-5 text-blue-600" />
        Calculateur DFG Cockroft-Gault
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          label="Âge"
          name="age"
          value={values.age}
          onChange={handleChange('age')}
          description="Âge en années"
          placeholder="Ex: 65"
          required
        />
        
        <FormField
          label="Poids"
          name="weight"
          value={values.weight}
          onChange={handleChange('weight')}
          description="Poids en kg"
          placeholder="Ex: 70"
          required
        />
        
        <FormField
          label="Créatinine"
          name="creatinine"
          value={values.creatinine}
          onChange={handleChange('creatinine')}
          description="Créatinine en µmol/L"
          placeholder="Ex: 80"
          required
        />

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-gray-900">
            Sexe
          </label>
          <div className="flex gap-4">
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={values.gender === 'male'}
                onChange={() => handleChange('gender')('male')}
                className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-900">Homme</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                checked={values.gender === 'female'}
                onChange={() => handleChange('gender')('female')}
                className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-900">Femme</span>
            </label>
          </div>
        </div>
      </div>

      <div className="mt-6 flex flex-col md:flex-row justify-between items-center gap-4">
        <button
          onClick={calculateDFG}
          className="w-full md:w-auto px-6 py-3 bg-blue-600 text-white font-medium rounded-lg 
                   hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 
                   focus:ring-offset-2 transition-colors duration-200"
        >
          Calculer
        </button>
        
        {dfg !== null && (
          <div className="text-center md:text-right">
            <div className="text-2xl font-bold text-blue-900">
              DFG = {dfg} mL/min
            </div>
            <div className={`text-sm font-medium mt-1 ${getStage(dfg).color}`}>
              {getStage(dfg).stage}
            </div>
          </div>
        )}
      </div>

      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <p className="text-sm font-medium text-gray-900 mb-2">
          Formule de Cockroft-Gault: DFG = [(140 - âge) × poids × K] / (créatinine × 0.814)
        </p>
        <p className="text-sm text-gray-600">
          K = 1 pour les hommes, 0.85 pour les femmes
        </p>
      </div>
    </div>
  );
}