export const mitralStenosisClassification = {
  title: 'Classification de la Sténose Mitrale',
  headers: [
    'Sévérité',
    'Surface (cm²)',
    'Gradient Moyen (mmHg)',
    'PAPs (mmHg)',
    'Surface indexée (cm²/m²)'
  ],
  rows: [
    {
      severity: 'Légère',
      criteria: ['>1.5', '<5', '<30', '>1.0']
    },
    {
      severity: 'Modérée',
      criteria: ['1.0-1.5', '5-10', '30-50', '0.6-1.0']
    },
    {
      severity: 'Sévère',
      criteria: ['<1.0', '>10', '>50', '<0.6']
    }
  ]
};

export const mitralInsufficiencyClassification = {
  title: 'Classification de l\'Insuffisance Mitrale',
  headers: ['Sévérité', 'ORE (mm²)', 'Volume Régurgité (ml)', 'Vena Contracta (mm)'],
  rows: [
    {
      severity: 'Légère',
      criteria: ['<20', '<30', '<3']
    },
    {
      severity: 'Modérée',
      criteria: ['20-39', '30-59', '3-6.9']
    },
    {
      severity: 'Sévère',
      criteria: ['≥40', '≥60', '≥7']
    }
  ]
};

export const aorticStenosisClassification = {
  title: 'Classification de la Sténose Aortique',
  headers: ['Sévérité', 'Surface (cm²)', 'Gradient Moyen (mmHg)', 'Vitesse Max (m/s)'],
  rows: [
    {
      severity: 'Légère',
      criteria: ['>1.5', '<20', '<3.0']
    },
    {
      severity: 'Modérée',
      criteria: ['1.0-1.5', '20-40', '3.0-4.0']
    },
    {
      severity: 'Sévère',
      criteria: ['<1.0', '>40', '>4.0']
    }
  ]
};

export const aorticInsufficiencyClassification = {
  title: 'Classification de l\'Insuffisance Aortique',
  headers: ['Sévérité', 'Vena Contracta (mm)', 'PHT (ms)', 'Reflux Holodiastolique'],
  rows: [
    {
      severity: 'Légère',
      criteria: ['<3', '>500', 'Non']
    },
    {
      severity: 'Modérée',
      criteria: ['3-6', '200-500', 'Variable']
    },
    {
      severity: 'Sévère',
      criteria: ['>6', '<200', 'Oui']
    }
  ]
};

export const tricuspidStenosisClassification = {
  title: 'Classification de la Sténose Tricuspide',
  headers: ['Sévérité', 'Surface (cm²)', 'Gradient Moyen (mmHg)'],
  rows: [
    {
      severity: 'Légère',
      criteria: ['>1.5', '<2']
    },
    {
      severity: 'Modérée',
      criteria: ['1.0-1.5', '2-5']
    },
    {
      severity: 'Sévère',
      criteria: ['<1.0', '>5']
    }
  ]
};

export const tricuspidInsufficiencyClassification = {
  title: 'Classification de l\'Insuffisance Tricuspide',
  headers: ['Sévérité', 'PAPS (mmHg)', 'Vitesse IT (m/s)', 'Tenting Area (cm²)'],
  rows: [
    {
      severity: 'Légère',
      criteria: ['<35', '<2.8', '<1']
    },
    {
      severity: 'Modérée',
      criteria: ['35-50', '2.8-3.4', '1-2']
    },
    {
      severity: 'Sévère',
      criteria: ['>50', '>3.4', '>2']
    }
  ]
};

export const pulmonaryStenosisClassification = {
  title: 'Classification de la Sténose Pulmonaire',
  headers: ['Sévérité', 'Gradient Moyen (mmHg)', 'Vitesse Max (m/s)'],
  rows: [
    {
      severity: 'Légère',
      criteria: ['<20', '<3.0']
    },
    {
      severity: 'Modérée',
      criteria: ['20-40', '3.0-4.0']
    },
    {
      severity: 'Sévère',
      criteria: ['>40', '>4.0']
    }
  ]
};

export const pulmonaryInsufficiencyClassification = {
  title: 'Classification de l\'Insuffisance Pulmonaire',
  headers: ['Sévérité', 'Vena Contracta (mm)', 'PHT (ms)'],
  rows: [
    {
      severity: 'Légère',
      criteria: ['<3', '>200']
    },
    {
      severity: 'Modérée',
      criteria: ['3-6', '100-200']
    },
    {
      severity: 'Sévère',
      criteria: ['>6', '<100']
    }
  ]
};