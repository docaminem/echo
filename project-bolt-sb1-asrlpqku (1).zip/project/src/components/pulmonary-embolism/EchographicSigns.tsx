import React from 'react';
import { Heart } from 'lucide-react';

export function EchographicSigns() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Heart className="w-5 h-5 text-blue-600" />
        Signes Échographiques
      </h2>

      <div className="space-y-6">
        <div>
          <h3 className="font-medium text-gray-900 mb-3">Signes Directs</h3>
          <div className="grid gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900">Thrombus visible</h4>
              <ul className="mt-2 space-y-1 text-blue-700">
                <li>• Visualisation directe du thrombus dans l'AP</li>
                <li>• Aspect mobile ou fixe</li>
                <li>• Localisation centrale ou périphérique</li>
              </ul>
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-medium text-gray-900 mb-3">Signes Indirects</h3>
          <div className="grid gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium">Dilatation des cavités droites</h4>
              <ul className="mt-2 space-y-1 text-gray-600">
                <li>• Rapport VD/VG supérieur à 0.9 en 4 cavités</li>
                <li>• Septum paradoxal</li>
                <li>• Dilatation de l'AP (supérieure à 25mm)</li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <h4 className="font-medium">Dysfonction VD</h4>
              <ul className="mt-2 space-y-1 text-gray-600">
                <li>• TAPSE inférieur à 17mm</li>
                <li>• Onde S' inférieure à 9.5 cm/s</li>
                <li>• Signe de McConnell</li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <h4 className="font-medium">Hypertension pulmonaire</h4>
              <ul className="mt-2 space-y-1 text-gray-600">
                <li>• PAPS supérieure à 40 mmHg</li>
                <li>• Temps d'accélération pulmonaire inférieur à 100ms</li>
                <li>• Profil en "W" du flux d'éjection pulmonaire</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="p-4 bg-yellow-50 rounded-lg">
          <h4 className="font-medium text-yellow-900">Points Clés</h4>
          <ul className="mt-2 space-y-1 text-yellow-700">
            <li>• L'absence de signes n'élimine pas le diagnostic</li>
            <li>• La présence de signes indirects doit faire rechercher une EP</li>
            <li>• Les signes de gravité orientent la prise en charge</li>
          </ul>
        </div>
      </div>
    </div>
  );
}