import React, { useState } from 'react';
import { ArrowDownCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function MitralStenosis() {
  const [values, setValues] = useState({
    surface: '',
    meanGradient: '',
    halfTime: '',
    papSystolic: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-orange-700">
        <ArrowDownCircle className="w-4 h-4" />
        Sténose Mitrale
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="Surface Valve"
          name="mitralStenosisSurface"
          value={values.surface}
          onChange={handleChange('surface')}
          description="Surface valvulaire mitrale en cm²"
          placeholder="Ex: 1.5"
          step="0.1"
        />
        <FormField
          label="Gradient Moyen"
          name="mitralStenosisMeanGradient"
          value={values.meanGradient}
          onChange={handleChange('meanGradient')}
          description="Gradient moyen transmitral en mmHg"
          placeholder="Ex: 8"
          step="0.1"
        />
        <FormField
          label="Temps de Demi-Pression"
          name="mitralStenosisHalfTime"
          value={values.halfTime}
          onChange={handleChange('halfTime')}
          description="Temps de demi-pression en ms"
          placeholder="Ex: 150"
          step="1"
        />
        <FormField
          label="PAP Systolique"
          name="mitralStenosisPapSystolic"
          value={values.papSystolic}
          onChange={handleChange('papSystolic')}
          description="Pression artérielle pulmonaire systolique en mmHg"
          placeholder="Ex: 35"
          step="1"
        />
      </div>
    </div>
  );
}