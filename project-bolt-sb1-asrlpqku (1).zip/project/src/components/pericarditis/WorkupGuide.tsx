import React from 'react';
import { FileText, AlertCircle } from 'lucide-react';

export function WorkupGuide() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
        <FileText className="w-5 h-5 text-blue-600" />
        Bilan Initial
      </h2>

      <div className="space-y-6">
        <div>
          <h3 className="font-medium text-gray-900 mb-2">Bilan Systématique</h3>
          <ul className="list-disc list-inside space-y-1 text-gray-600">
            <li>ECG 12 dérivations</li>
            <li>Radiographie thoracique</li>
            <li>Échocardiographie</li>
            <li>NFS, CRP</li>
            <li>Troponine, NT-proBNP</li>
            <li>Fonction rénale, ionogramme</li>
            <li>TSH</li>
          </ul>
        </div>

        <div>
          <h3 className="font-medium text-gray-900 mb-2">Selon le Contexte</h3>
          <ul className="list-disc list-inside space-y-1 text-gray-600">
            <li>Sérologies virales (Coxsackie, Echo, EBV, CMV, Parvovirus B19)</li>
            <li>Bilan auto-immun (si forme récurrente)</li>
            <li>Hémocultures (si fièvre)</li>
            <li>IDR tuberculine / Quantiféron</li>
            <li>IRM cardiaque (si doute diagnostique)</li>
          </ul>
        </div>

        <div className="bg-yellow-50 p-4 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-yellow-800">Signes de Gravité</h4>
              <ul className="mt-2 space-y-1 text-yellow-700">
                <li>• Tamponnade</li>
                <li>• Épanchement abondant</li>
                <li>• Myopéricardite avec dysfonction VG</li>
                <li>• Absence de réponse au traitement initial</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}