import { ValveRecommendations } from '../../types/recommendations';

export function getAorticStenosisRecommendations(
  severity: string,
  ef: number,
  age: number = 75,
  highSurgicalRisk: boolean = true,
  symptoms: boolean = true,
  lowFlow: boolean = false,
  paradoxicalLowFlow: boolean = false
): ValveRecommendations {
  if (severity === 'Sévère') {
    // Sténose aortique sévère symptomatique
    if (symptoms) {
      const recommendations: ValveRecommendations = {
        treatment: [
          {
            indication: 'RVAo chirurgical',
            class: 'I',
            levelOfEvidence: 'B',
            description: 'Première intention chez le patient à bas risque'
          }
        ],
        followUp: [
          'Échocardiographie à 1 mois post-intervention',
          'Suivi à 1, 6 et 12 mois puis annuel',
          'Anticoagulation si valve mécanique',
          'Double anti-agrégation si TAVI'
        ],
        additionalConsiderations: [
          'Choix de la voie d\'abord selon anatomie',
          'Discussion Heart Team',
          'Évaluation gériatrique si âge > 75 ans'
        ]
      };

      // Add TAVI recommendation for high-risk/elderly patients
      if (age >= 75 || highSurgicalRisk) {
        recommendations.treatment.push({
          indication: 'TAVI',
          class: 'I',
          levelOfEvidence: 'A',
          description: 'Si risque chirurgical élevé ou âge > 75 ans'
        });
      }

      return recommendations;
    }

    // Rest of the function remains the same...
    // [Previous code for other conditions]
  }

  return {
    treatment: [
      {
        indication: 'Surveillance',
        class: 'I',
        levelOfEvidence: 'C',
        description: 'Suivi clinique et échographique régulier'
      }
    ],
    followUp: [
      'Échocardiographie annuelle si modérée',
      'Échocardiographie tous les 2-3 ans si légère',
      'Contrôle des facteurs de risque'
    ]
  };
}

// Rest of the file remains the same...