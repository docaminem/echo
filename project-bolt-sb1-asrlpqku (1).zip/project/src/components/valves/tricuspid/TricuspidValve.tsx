import React, { useState } from 'react';
import { Waves, ArrowDownCircle, ArrowUpCircle, Calculator } from 'lucide-react';
import { ValveSection } from '../../common/ValveSection';
import { TricuspidStenosis } from './TricuspidStenosis';
import { TricuspidInsufficiency } from './TricuspidInsufficiency';
import { TricuspidClassificationTable } from './TricuspidClassificationTable';
import { PapsCalculator } from './PapsCalculator';

export function TricuspidValve() {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const sections = [
    {
      id: 'stenosis',
      title: 'Sténose Tricuspide',
      icon: ArrowDownCircle,
      component: TricuspidStenosis
    },
    {
      id: 'insufficiency',
      title: 'Insuffisance Tricuspide',
      icon: ArrowUpCircle,
      component: TricuspidInsufficiency
    },
    {
      id: 'paps',
      title: 'Calculateur PAPS',
      icon: Calculator,
      component: PapsCalculator
    }
  ];

  return (
    <ValveSection title="Valve Tricuspide" icon={Waves}>
      <div className="space-y-4">
        {sections.map(section => (
          <div key={section.id}>
            <button
              onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
              className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                       hover:bg-gray-50 transition-colors duration-200"
            >
              <div className="flex items-center gap-3">
                <section.icon className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-gray-900">{section.title}</span>
              </div>
              <div className="text-blue-600">
                {activeSection === section.id ? '▼' : '▶'}
              </div>
            </button>
            
            {activeSection === section.id && (
              <div className="mt-4 space-y-6">
                <section.component />
                {section.id !== 'paps' && <TricuspidClassificationTable />}
              </div>
            )}
          </div>
        ))}
      </div>
    </ValveSection>
  );
}