import React from 'react';
import { Pill, AlertCircle } from 'lucide-react';

export function DetailedTreatmentGuide() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Pill className="w-5 h-5 text-blue-600" />
        Guide Thérapeutique Détaillé
      </h2>

      <div className="space-y-8">
        {/* Haut Risque */}
        <div className="p-6 bg-red-50 rounded-lg">
          <h3 className="text-lg font-medium text-red-900 mb-4">EP à Haut Risque (Massive)</h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-red-800 mb-2">Thrombolyse</h4>
              <div className="space-y-2">
                <div className="bg-white p-3 rounded border border-red-100">
                  <p className="font-medium text-red-900">Alteplase (rt-PA)</p>
                  <ul className="mt-1 space-y-1 text-red-700 text-sm">
                    <li>• Dose : 100 mg</li>
                    <li>• Administration : 10 mg en bolus puis 90 mg sur 2h</li>
                    <li>• Voie : Intraveineuse</li>
                    <li>• Durée : Dose unique</li>
                  </ul>
                </div>

                <div className="bg-white p-3 rounded border border-red-100">
                  <p className="font-medium text-red-900">Alternative : Tenecteplase</p>
                  <ul className="mt-1 space-y-1 text-red-700 text-sm">
                    <li>• Dose : 30-50 mg selon le poids</li>
                    <li>• Administration : Bolus unique</li>
                    <li>• Voie : Intraveineuse</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-red-800 mb-2">Anticoagulation associée</h4>
              <div className="bg-white p-3 rounded border border-red-100">
                <p className="font-medium text-red-900">Héparine Non Fractionnée (HNF)</p>
                <ul className="mt-1 space-y-1 text-red-700 text-sm">
                  <li>• Bolus : 80 UI/kg</li>
                  <li>• Maintenance : 18 UI/kg/h</li>
                  <li>• Ajustement selon anti-Xa (objectif 0.3-0.7)</li>
                  <li>• Surveillance : TCA/anti-Xa toutes les 4-6h</li>
                </ul>
              </div>
            </div>

            <div className="bg-red-100 p-3 rounded-lg">
              <p className="font-medium text-red-900 flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                Contre-indications absolues à la thrombolyse
              </p>
              <ul className="mt-2 space-y-1 text-red-700 text-sm">
                <li>• AVC hémorragique ou ischémique récent (&lt;3 mois)</li>
                <li>• Traumatisme crânien récent</li>
                <li>• Chirurgie majeure &lt;2 semaines</li>
                <li>• Hémorragie active</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Risque Intermédiaire */}
        <div className="p-6 bg-orange-50 rounded-lg">
          <h3 className="text-lg font-medium text-orange-900 mb-4">EP à Risque Intermédiaire</h3>
          
          <div className="space-y-4">
            <div className="bg-white p-3 rounded border border-orange-100">
              <p className="font-medium text-orange-900">HBPM - Énoxaparine (Lovenox®)</p>
              <ul className="mt-1 space-y-1 text-orange-700 text-sm">
                <li>• Dose : 1 mg/kg toutes les 12h</li>
                <li>• Voie : Sous-cutanée</li>
                <li>• Durée initiale : 5-10 jours</li>
                <li>• Ajustements :</li>
                <ul className="ml-4 space-y-1">
                  <li>- Si poids &gt;100kg : max 10000 UI/12h</li>
                  <li>- Si DFG 15-30 : 1 mg/kg/24h</li>
                  <li>- Si DFG &lt;15 : utiliser HNF</li>
                </ul>
              </ul>
            </div>

            <div className="bg-white p-3 rounded border border-orange-100">
              <p className="font-medium text-orange-900">Alternative : Fondaparinux (Arixtra®)</p>
              <ul className="mt-1 space-y-1 text-orange-700 text-sm">
                <li>• Dosage selon le poids :</li>
                <ul className="ml-4">
                  <li>- &lt;50 kg : 5 mg/24h</li>
                  <li>- 50-100 kg : 7.5 mg/24h</li>
                  <li>- &gt;100 kg : 10 mg/24h</li>
                </ul>
                <li>• Contre-indiqué si DFG &lt;30</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bas Risque */}
        <div className="p-6 bg-green-50 rounded-lg">
          <h3 className="text-lg font-medium text-green-900 mb-4">EP à Bas Risque</h3>
          
          <div className="space-y-4">
            <div className="bg-white p-3 rounded border border-green-100">
              <p className="font-medium text-green-900">Rivaroxaban (Xarelto®)</p>
              <ul className="mt-1 space-y-1 text-green-700 text-sm">
                <li>• Phase initiale : 15 mg x 2/j pendant 21 jours</li>
                <li>• Phase d'entretien : 20 mg/j en une prise</li>
                <li>• Prise : Pendant les repas</li>
                <li>• Ajustements :</li>
                <ul className="ml-4">
                  <li>- Si DFG 15-49 : 15 mg x 2/j puis 15 mg/j</li>
                  <li>- Si DFG &lt;15 : contre-indiqué</li>
                </ul>
              </ul>
            </div>

            <div className="bg-white p-3 rounded border border-green-100">
              <p className="font-medium text-green-900">Apixaban (Eliquis®)</p>
              <ul className="mt-1 space-y-1 text-green-700 text-sm">
                <li>• Phase initiale : 10 mg x 2/j pendant 7 jours</li>
                <li>• Phase d'entretien : 5 mg x 2/j</li>
                <li>• Prise : Indépendante des repas</li>
                <li>• Pas d'ajustement si DFG &gt;15</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Durée de traitement */}
        <div className="p-6 bg-gray-50 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Durée du Traitement</h3>
          
          <div className="space-y-4">
            <div className="bg-white p-3 rounded border">
              <p className="font-medium">EP provoquée par facteur transitoire</p>
              <ul className="mt-1 space-y-1 text-gray-600 text-sm">
                <li>• Durée : 3-6 mois</li>
                <li>• Réévaluation à 3 mois</li>
              </ul>
            </div>

            <div className="bg-white p-3 rounded border">
              <p className="font-medium">EP non provoquée</p>
              <ul className="mt-1 space-y-1 text-gray-600 text-sm">
                <li>• Durée minimale : 6 mois</li>
                <li>• Évaluation bénéfice/risque pour traitement prolongé</li>
              </ul>
            </div>

            <div className="bg-white p-3 rounded border">
              <p className="font-medium">EP et cancer actif</p>
              <ul className="mt-1 space-y-1 text-gray-600 text-sm">
                <li>• HBPM pendant 6 mois</li>
                <li>• Poursuite tant que cancer actif</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Surveillance */}
        <div className="p-6 bg-blue-50 rounded-lg">
          <h3 className="text-lg font-medium text-blue-900 mb-4">Surveillance du Traitement</h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-blue-800 mb-2">Surveillance biologique</h4>
              <ul className="space-y-2 text-blue-700 text-sm">
                <li>• HBPM : plaquettes 2 fois/semaine pendant 1 mois</li>
                <li>• HNF : TCA/anti-Xa toutes les 4-6h jusqu'à stabilisation</li>
                <li>• AOD : fonction rénale tous les 3-6 mois</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-blue-800 mb-2">Surveillance clinique</h4>
              <ul className="space-y-2 text-blue-700 text-sm">
                <li>• Évaluation à J7-J10</li>
                <li>• Puis mensuelle les 3-6 premiers mois</li>
                <li>• Recherche de signes hémorragiques</li>
                <li>• Évaluation de l'observance</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}