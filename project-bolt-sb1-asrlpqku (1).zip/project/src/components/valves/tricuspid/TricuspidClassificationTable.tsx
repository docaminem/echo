import React from 'react';
import { tricuspidClassification } from '../../../data/tricuspidClassification';

export function TricuspidClassificationTable() {
  const renderTable = (
    data: typeof tricuspidClassification.qualitative | 
          typeof tricuspidClassification.semiquantitative | 
          typeof tricuspidClassification.consequences
  ) => (
    <div className="mb-6">
      <h4 className="text-sm font-medium text-gray-700 mb-2">{data.title}</h4>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 border rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              {data.headers.map((header, index) => (
                <th
                  key={index}
                  className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.rows.map((row, index) => (
              <tr key={index}>
                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-700">
                  {row.parameter}
                </td>
                {row.criteria.map((criterion, idx) => (
                  <td key={idx} className="px-4 py-2 text-sm text-gray-500">
                    {criterion}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {renderTable(tricuspidClassification.qualitative)}
      {renderTable(tricuspidClassification.semiquantitative)}
      {renderTable(tricuspidClassification.consequences)}
    </div>
  );
}