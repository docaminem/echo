import React, { useState } from 'react';
import { ArrowUpCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function MitralInsufficiency() {
  const [values, setValues] = useState({
    pisa: '',
    ore: '',
    regurgitationVolume: '',
    venaContracta: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-red-700">
        <ArrowUpCircle className="w-4 h-4" />
        Insuffisance Mitrale
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="PISA"
          name="mitralInsufficiencyPisa"
          value={values.pisa}
          onChange={handleChange('pisa')}
          description="Rayon de la zone de convergence PISA en cm"
          placeholder="Ex: 0.7"
          step="0.1"
        />
        <FormField
          label="ORE"
          name="mitralInsufficiencyOre"
          value={values.ore}
          onChange={handleChange('ore')}
          description="Surface de l'orifice régurgitant effectif en mm²"
          placeholder="Ex: 30"
          step="1"
        />
        <FormField
          label="Volume Régurgité"
          name="mitralInsufficiencyVolume"
          value={values.regurgitationVolume}
          onChange={handleChange('regurgitationVolume')}
          description="Volume régurgité en mL"
          placeholder="Ex: 45"
          step="1"
        />
        <FormField
          label="Vena Contracta"
          name="mitralInsufficiencyVenaContracta"
          value={values.venaContracta}
          onChange={handleChange('venaContracta')}
          description="Largeur de la vena contracta en mm"
          placeholder="Ex: 5"
          step="0.1"
        />
      </div>
    </div>
  );
}