import React from 'react';
import type { FillingPressuresData } from '../../types/filling-pressures';

interface FillingPressuresResultsProps {
  data: FillingPressuresData;
}

export function FillingPressuresResults({ data }: FillingPressuresResultsProps) {
  const { calculations, interpretation } = data;

  return (
    <div className="mt-6 md:mt-8 space-y-4 md:space-y-6">
      <h2 className="text-lg font-semibold text-gray-900">Résultats</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gray-50 p-3 md:p-4 rounded-lg">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Calculs</h3>
          <dl className="space-y-2">
            {calculations.eToARatio !== undefined && (
              <div className="flex justify-between">
                <dt className="text-sm text-gray-600">Rapport E/A:</dt>
                <dd className="text-sm font-medium">{calculations.eToARatio.toFixed(2)}</dd>
              </div>
            )}
            <div className="flex justify-between">
              <dt className="text-sm text-gray-600">Moyenne e':</dt>
              <dd className="text-sm font-medium">{calculations.averageEa.toFixed(2)} cm/s</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm text-gray-600">Rapport E/e':</dt>
              <dd className="text-sm font-medium">{calculations.eToAverageTdRatio.toFixed(2)}</dd>
            </div>
          </dl>
        </div>

        <div className="bg-gray-50 p-3 md:p-4 rounded-lg">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Interprétation</h3>
          <div className={`text-sm font-medium ${interpretation.color}`}>
            {interpretation.conclusion}
          </div>
          <p className="text-sm text-gray-600 mt-2">{interpretation.details}</p>
        </div>

        {interpretation.additionalFindings && interpretation.additionalFindings.length > 0 && (
          <div className="col-span-1 md:col-span-2 bg-gray-50 p-3 md:p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Critères additionnels:</h3>
            <ul className="text-sm text-gray-600 list-disc list-inside space-y-1">
              {interpretation.additionalFindings.map((finding, index) => (
                <li key={index}>{finding}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}