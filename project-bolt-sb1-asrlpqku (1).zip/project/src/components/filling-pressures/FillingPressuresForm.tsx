import React, { useState } from 'react';
import { interpretResults } from '../../utils/filling-pressures';
import type { FillingPressuresData } from '../../types/filling-pressures';
import { FormField } from '../common/FormField';

interface FillingPressuresFormProps {
  onCalculate: (data: FillingPressuresData) => void;
}

export function FillingPressuresForm({ onCalculate }: FillingPressuresFormProps) {
  const [formData, setFormData] = useState({
    waveE: '',
    waveA: '',
    decelerationTime: '',
    septalEa: '',
    lateralEa: '',
    preservedEF: true,
    paps: '',
    leftAtrialVolume: '',
    hasAtrialFibrillation: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const averageEa = (Number(formData.septalEa) + Number(formData.lateralEa)) / 2;
    const eToAverageTdRatio = Number(formData.waveE) / averageEa;
    const eToARatio = formData.hasAtrialFibrillation ? undefined : 
      Number(formData.waveE) / Number(formData.waveA);

    onCalculate({
      measurements: {
        waveE: Number(formData.waveE),
        waveA: formData.hasAtrialFibrillation ? undefined : Number(formData.waveA),
        decelerationTime: Number(formData.decelerationTime),
        septalEa: Number(formData.septalEa),
        lateralEa: Number(formData.lateralEa),
        preservedEF: formData.preservedEF,
        paps: formData.paps ? Number(formData.paps) : undefined,
        leftAtrialVolume: formData.leftAtrialVolume ? Number(formData.leftAtrialVolume) : undefined,
        hasAtrialFibrillation: formData.hasAtrialFibrillation,
      },
      calculations: {
        eToAverageTdRatio,
        eToARatio,
        averageEa,
      },
      interpretation: interpretResults({
        eToAverageTdRatio,
        eToARatio,
        decelerationTime: Number(formData.decelerationTime),
        preservedEF: formData.preservedEF,
        paps: formData.paps ? Number(formData.paps) : undefined,
        leftAtrialVolume: formData.leftAtrialVolume ? Number(formData.leftAtrialVolume) : undefined,
        hasAtrialFibrillation: formData.hasAtrialFibrillation,
      }),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4 md:space-y-6">
        <div className="p-3 md:p-4 bg-gray-50 rounded-lg border border-gray-200">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={formData.hasAtrialFibrillation}
              onChange={(e) => setFormData({ ...formData, hasAtrialFibrillation: e.target.checked })}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-gray-900">Fibrillation atriale</span>
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          <FormField
            label="Onde E mitrale"
            name="waveE"
            value={formData.waveE}
            onChange={(value) => setFormData({ ...formData, waveE: value })}
            description="Vitesse maximale de l'onde E en cm/s"
            placeholder="Ex: 80"
            required
          />
          
          {!formData.hasAtrialFibrillation && (
            <FormField
              label="Onde A mitrale"
              name="waveA"
              value={formData.waveA}
              onChange={(value) => setFormData({ ...formData, waveA: value })}
              description="Vitesse maximale de l'onde A en cm/s"
              placeholder="Ex: 60"
              required
            />
          )}
          
          <FormField
            label="Temps de décélération"
            name="decelerationTime"
            value={formData.decelerationTime}
            onChange={(value) => setFormData({ ...formData, decelerationTime: value })}
            description="Temps de décélération de l'onde E en ms"
            placeholder="Ex: 200"
            required
          />
          
          <FormField
            label="Vitesse Ea septale"
            name="septalEa"
            value={formData.septalEa}
            onChange={(value) => setFormData({ ...formData, septalEa: value })}
            description="Vitesse de l'onde Ea au niveau septal en cm/s"
            placeholder="Ex: 7"
            required
          />
          
          <FormField
            label="Vitesse Ea latérale"
            name="lateralEa"
            value={formData.lateralEa}
            onChange={(value) => setFormData({ ...formData, lateralEa: value })}
            description="Vitesse de l'onde Ea au niveau latéral en cm/s"
            placeholder="Ex: 10"
            required
          />
          
          <FormField
            label="PAPS"
            name="paps"
            value={formData.paps}
            onChange={(value) => setFormData({ ...formData, paps: value })}
            description="Pression artérielle pulmonaire systolique en mmHg"
            placeholder="Ex: 35"
          />
          
          <FormField
            label="Volume OG"
            name="leftAtrialVolume"
            value={formData.leftAtrialVolume}
            onChange={(value) => setFormData({ ...formData, leftAtrialVolume: value })}
            description="Volume de l'oreillette gauche en mL"
            placeholder="Ex: 28"
          />
        </div>
        
        <div className="p-3 md:p-4 bg-gray-50 rounded-lg border border-gray-200">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={formData.preservedEF}
              onChange={(e) => setFormData({ ...formData, preservedEF: e.target.checked })}
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-gray-900">FEVG préservée (&gt;50%)</span>
          </label>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button
          type="submit"
          className="w-full md:w-auto px-6 py-3 bg-blue-600 text-white font-medium rounded-lg 
                   hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 
                   focus:ring-offset-2 transition-colors duration-200"
        >
          Calculer
        </button>
      </div>
    </form>
  );
}