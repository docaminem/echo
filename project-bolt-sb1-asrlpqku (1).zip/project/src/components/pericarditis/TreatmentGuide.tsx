import React from 'react';
import { Pill } from 'lucide-react';

export function TreatmentGuide() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
        <Pill className="w-5 h-5 text-blue-600" />
        Guide Thérapeutique
      </h2>

      <div className="space-y-6">
        <div>
          <h3 className="font-medium text-gray-900 mb-3">Traitement Initial</h3>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900">Aspirine ou AINS</h4>
              <div className="mt-2 space-y-2">
                <p className="text-blue-700">Dose d'attaque (7-14 jours) :</p>
                <ul className="list-disc list-inside text-blue-700 ml-2">
                  <li>Aspirine : 750-1000 mg x 3/j</li>
                  <li>ou Ibuprofène : 600 mg x 3/j</li>
                </ul>
                <p className="text-blue-700">Décroissance sur 2-4 semaines :</p>
                <ul className="list-disc list-inside text-blue-700 ml-2">
                  <li>Aspirine : 
                    <ul className="list-none ml-6 text-blue-600">
                      <li>• Semaine 1 : 500 mg x 3/j</li>
                      <li>• Semaine 2 : 500 mg x 2/j</li>
                      <li>• Semaine 3 : 250 mg x 2/j</li>
                      <li>• Semaine 4 : 250 mg x 1/j</li>
                    </ul>
                  </li>
                  <li>Ibuprofène :
                    <ul className="list-none ml-6 text-blue-600">
                      <li>• Semaine 1 : 400 mg x 3/j</li>
                      <li>• Semaine 2 : 400 mg x 2/j</li>
                      <li>• Semaine 3 : 200 mg x 2/j</li>
                      <li>• Semaine 4 : 200 mg x 1/j</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-medium text-green-900">Colchicine</h4>
              <p className="mt-1 text-green-700">
                0.5 mg x 2/j (&lt; 70 kg) ou 0.5 mg x 3/j (&gt; 70 kg)
              </p>
              <p className="mt-2 text-sm text-green-600">
                Durée: 3 mois pour prévenir les récidives
              </p>
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-medium text-gray-900 mb-3">Cas Particuliers</h3>
          <div className="grid gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium">Forme Récidivante</h4>
              <ul className="mt-2 space-y-1 text-gray-600">
                <li>• Colchicine longue durée (6-12 mois)</li>
                <li>• Considérer corticothérapie faible dose (0.2-0.5 mg/kg/j)</li>
                <li>• Bilan étiologique approfondi</li>
              </ul>
            </div>

            <div className="p-4 border rounded-lg">
              <h4 className="font-medium">Forme Cortico-dépendante</h4>
              <ul className="mt-2 space-y-1 text-gray-600">
                <li>• Envisager immunosuppresseurs</li>
                <li>• Avis spécialisé</li>
                <li>• Recherche maladie systémique</li>
              </ul>
            </div>

            <div className="p-4 bg-red-50 rounded-lg">
              <h4 className="font-medium text-red-900">Contre-indications</h4>
              <ul className="mt-2 space-y-1 text-red-700">
                <li>• AINS si anticoagulation efficace</li>
                <li>• Colchicine si insuffisance rénale sévère</li>
                <li>• Corticoïdes en première intention (risque de chronicisation)</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-2">Suivi</h4>
          <ul className="space-y-2 text-gray-600">
            <li>• Clinique et ECG à 1 semaine</li>
            <li>• CRP à 1 semaine pour évaluer la réponse</li>
            <li>• Échocardiographie à 1 mois</li>
            <li>• Suivi prolongé si forme récidivante</li>
          </ul>
        </div>
      </div>
    </div>
  );
}