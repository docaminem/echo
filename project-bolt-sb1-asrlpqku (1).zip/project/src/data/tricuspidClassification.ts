export const tricuspidClassification = {
  qualitative: {
    title: 'Paramètres Qualitatifs',
    headers: ['Paramètre', 'Minime', 'Légère', 'Modérée', 'Sévère'],
    rows: [
      {
        parameter: 'Morphologie des feuillets',
        criteria: [
          'Normale',
          'Normale ou anormale',
          'Anormale',
          'Anomalie sévère/Flail'
        ]
      },
      {
        parameter: 'Flux couleur du jet',
        criteria: [
          'Petit central',
          'Petit central',
          'Jet large central',
          'Jet très large ou excentré'
        ]
      },
      {
        parameter: 'Signal CW du jet',
        criteria: [
          'Faible/Parabolique',
          'Parabolique',
          'Dense',
          'Dense/Triangulaire'
        ]
      }
    ]
  },
  semiquantitative: {
    title: 'Paramètres Semi-quantitatifs',
    headers: ['Paramètre', 'Minime', 'Légère', 'Modérée', 'Sévère'],
    rows: [
      {
        parameter: 'Vena Contracta (mm)',
        criteria: ['Non défini', '<3', '3-6.9', '≥7']
      },
      {
        parameter: 'Rayon PISA (mm)',
        criteria: ['≤5', '≤5', '6-9', '>9']
      },
      {
        parameter: 'SORE (mm²)',
        criteria: ['Non définie', '<20', '20-39', '≥40']
      },
      {
        parameter: 'Volume régurgitant (mL/batt)',
        criteria: ['Non défini', '<30', '30-44', '≥45']
      },
      {
        parameter: 'Flux veineux hépatique',
        criteria: [
          'Dominance systolique',
          'Dominance systolique',
          'Émoussement systolique',
          'Inversion systolique'
        ]
      }
    ]
  },
  consequences: {
    title: 'Paramètres de Retentissement',
    headers: ['Paramètre', 'Minime/Légère', 'Modérée', 'Sévère'],
    rows: [
      {
        parameter: 'Surface OD (cm²)',
        criteria: ['<18', '18-25', '>25']
      },
      {
        parameter: 'Diamètre VD (mm)',
        criteria: ['<33', '33-40', '>40']
      },
      {
        parameter: 'PAPs (mmHg)',
        criteria: ['<35', '35-50', '>50']
      }
    ]
  }
};