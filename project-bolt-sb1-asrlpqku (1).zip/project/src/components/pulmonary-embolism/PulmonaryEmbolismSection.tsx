import React, { useState } from 'react';
import { Sun as Lung, Calculator } from 'lucide-react';
import { PulmonaryEmbolismCalculator } from './PulmonaryEmbolismCalculator';
import { ClinicalProbabilityCalculator } from './ClinicalProbabilityCalculator';
import { EchographicSigns } from './EchographicSigns';
import { DetailedTreatmentGuide } from './DetailedTreatmentGuide';

export function PulmonaryEmbolismSection() {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const sections = [
    {
      id: 'clinical-probability',
      title: 'Calculateur de Probabilité Clinique',
      component: ClinicalProbabilityCalculator
    },
    {
      id: 'echo-calculator',
      title: 'Calculateur Échocardiographique',
      component: PulmonaryEmbolismCalculator
    },
    {
      id: 'echo',
      title: 'Signes Échographiques',
      component: EchographicSigns
    },
    {
      id: 'treatment',
      title: 'Guide Thérapeutique',
      component: DetailedTreatmentGuide
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <header className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Lung className="w-6 h-6 text-blue-600" />
            Embolie Pulmonaire
          </h1>
          <p className="mt-2 text-gray-600">
            Aide au diagnostic et à la prise en charge de l'embolie pulmonaire
          </p>
        </header>

        <div className="space-y-4">
          {sections.map(section => (
            <div key={section.id}>
              <button
                onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
                className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                         hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center gap-3">
                  <Calculator className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">{section.title}</span>
                </div>
                <div className="text-blue-600">
                  {activeSection === section.id ? '▼' : '▶'}
                </div>
              </button>
              
              {activeSection === section.id && (
                <div className="mt-4">
                  <section.component />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}