import React, { useState } from 'react';
import { Activity, ArrowDownCircle, ArrowUpCircle } from 'lucide-react';
import { ValveSection } from '../../common/ValveSection';
import { AorticStenosis } from './AorticStenosis';
import { AorticInsufficiency } from './AorticInsufficiency';
import { ClassificationTable } from '../../common/ClassificationTable';
import { aorticStenosisClassification, aorticInsufficiencyClassification } from '../../../data/classifications';

export function AorticValve() {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const sections = [
    {
      id: 'stenosis',
      title: 'Sténose Aortique',
      icon: ArrowDownCircle,
      component: AorticStenosis,
      classification: aorticStenosisClassification
    },
    {
      id: 'insufficiency',
      title: 'Insuffisance Aortique',
      icon: ArrowUpCircle,
      component: AorticInsufficiency,
      classification: aorticInsufficiencyClassification
    }
  ];

  return (
    <ValveSection title="Valve Aortique" icon={Activity}>
      <div className="space-y-4">
        {sections.map(section => (
          <div key={section.id}>
            <button
              onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
              className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                       hover:bg-gray-50 transition-colors duration-200"
            >
              <div className="flex items-center gap-3">
                <section.icon className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-gray-900">{section.title}</span>
              </div>
              <div className="text-blue-600">
                {activeSection === section.id ? '▼' : '▶'}
              </div>
            </button>
            
            {activeSection === section.id && (
              <div className="mt-4 space-y-6">
                <section.component />
                <ClassificationTable {...section.classification} />
              </div>
            )}
          </div>
        ))}
      </div>
    </ValveSection>
  );
}