import { ValveData, DiagnosisResult } from '../../types/valve';

export function analyzeMitralStenosis(data: ValveData['mitral']['stenosis']): DiagnosisResult | null {
  if (!data.surface && !data.meanGradient && !data.halfTimePressure && !data.papSystolic) return null;

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  if (data.surface) {
    details.push(`Surface valvulaire: ${data.surface} cm²`);
    if (data.surface <= 1.0) severity = 'Sévère';
    else if (data.surface <= 1.5) severity = 'Modérée';
    else if (data.surface < 2.0) severity = 'Légère';
  }

  if (data.meanGradient) {
    details.push(`Gradient moyen: ${data.meanGradient} mmHg`);
    if (data.meanGradient >= 12) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.meanGradient >= 5) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (data.halfTimePressure) {
    details.push(`Temps de demi-pression: ${data.halfTimePressure} ms`);
    if (data.halfTimePressure >= 220) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.halfTimePressure >= 150) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (data.papSystolic) {
    details.push(`PAP systolique: ${data.papSystolic} mmHg`);
    if (data.papSystolic >= 50) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
      details.push('HTAP sévère');
    } else if (data.papSystolic >= 35) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
      details.push('HTAP modérée');
    }
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Mitrale',
    pathology: 'Sténose',
    severity,
    details
  };
}

export function analyzeMitralInsufficiency(data: ValveData['mitral']['insufficiency']): DiagnosisResult | null {
  if (!data.ore && !data.venaContracta && !data.pisa && !data.regurgitationVolume) return null;

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  if (data.ore) {
    details.push(`ORE: ${data.ore} mm²`);
    if (data.ore >= 40) severity = 'Sévère';
    else if (data.ore >= 20) severity = 'Modérée';
    else if (data.ore >= 10) severity = 'Légère';
  }

  if (data.venaContracta) {
    details.push(`Vena contracta: ${data.venaContracta} mm`);
    if (data.venaContracta >= 7) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.venaContracta >= 3) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (data.regurgitationVolume) {
    details.push(`Volume régurgité: ${data.regurgitationVolume} ml`);
    if (data.regurgitationVolume >= 60) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.regurgitationVolume >= 30) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Mitrale',
    pathology: 'Insuffisance',
    severity,
    details
  };
}