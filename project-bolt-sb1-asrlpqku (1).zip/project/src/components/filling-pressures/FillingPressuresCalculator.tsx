import React, { useState } from 'react';
import { Calculator } from 'lucide-react';
import { FillingPressuresForm } from './FillingPressuresForm';
import { FillingPressuresResults } from './FillingPressuresResults';
import { PapsCalculator } from '../valves/tricuspid/PapsCalculator';
import type { FillingPressuresData } from '../../types/filling-pressures';

export function FillingPressuresCalculator() {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [results, setResults] = useState<FillingPressuresData | null>(null);

  const sections = [
    {
      id: 'filling-pressures',
      title: 'Pressions de Remplissage VG',
      component: () => (
        <>
          <FillingPressuresForm onCalculate={setResults} />
          {results && <FillingPressuresResults data={results} />}
        </>
      )
    },
    {
      id: 'paps',
      title: 'Calculateur PAPS',
      component: PapsCalculator
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-4 md:py-8">
      <div className="max-w-4xl mx-auto px-3 md:px-4">
        <header className="mb-6 md:mb-8">
          <h1 className="text-xl md:text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Calculator className="w-5 md:w-6 h-5 md:h-6 text-blue-600" />
            Calculateurs Hémodynamiques
          </h1>
        </header>
        
        <div className="space-y-4">
          {sections.map(section => (
            <div key={section.id}>
              <button
                onClick={() => setActiveSection(activeSection === section.id ? null : section.id)}
                className="w-full flex items-center justify-between p-4 bg-white rounded-lg shadow-sm 
                         hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center gap-3">
                  <Calculator className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">{section.title}</span>
                </div>
                <div className="text-blue-600">
                  {activeSection === section.id ? '▼' : '▶'}
                </div>
              </button>
              
              {activeSection === section.id && (
                <div className="mt-4">
                  <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
                    <section.component />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}