import React, { useState } from 'react';
import { Calculator } from 'lucide-react';
import { FormField } from '../common/FormField';

interface EchoParameters {
  vdvgRatio: string;
  tapse: string;
  waveS: string;
  paps: string;
  rvDilation: boolean;
  paradoxicalSeptum: boolean;
  visibleThrombus: boolean;
  mcConnell: boolean;
}

export function PulmonaryEmbolismCalculator() {
  const [values, setValues] = useState<EchoParameters>({
    vdvgRatio: '',
    tapse: '',
    waveS: '',
    paps: '',
    rvDilation: false,
    paradoxicalSeptum: false,
    visibleThrombus: false,
    mcConnell: false
  });

  const [risk, setRisk] = useState<{
    level: 'Faible' | 'Intermédiaire' | 'Élevé';
    color: string;
    recommendations: string[];
  } | null>(null);

  const handleChange = (name: keyof EchoParameters) => (value: string | boolean) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  const calculateRisk = () => {
    const vdvgRatio = Number(values.vdvgRatio);
    const tapse = Number(values.tapse);
    const waveS = Number(values.waveS);
    const paps = Number(values.paps);

    let riskPoints = 0;

    // Critères majeurs
    if (values.visibleThrombus) riskPoints += 3;
    if (values.mcConnell) riskPoints += 2;
    if (vdvgRatio > 0.9) riskPoints += 2;
    if (paps > 50) riskPoints += 2;

    // Critères mineurs
    if (tapse < 17) riskPoints += 1;
    if (waveS < 9.5) riskPoints += 1;
    if (values.paradoxicalSeptum) riskPoints += 1;
    if (values.rvDilation) riskPoints += 1;

    let riskAssessment;
    if (riskPoints >= 5) {
      riskAssessment = {
        level: 'Élevé',
        color: 'text-red-600',
        recommendations: [
          'Hospitalisation en soins intensifs',
          'Thrombolyse à discuter',
          'Anticoagulation immédiate',
          'Surveillance hémodynamique rapprochée'
        ]
      };
    } else if (riskPoints >= 3) {
      riskAssessment = {
        level: 'Intermédiaire',
        color: 'text-orange-600',
        recommendations: [
          'Hospitalisation conventionnelle',
          'Anticoagulation immédiate',
          'Surveillance rapprochée',
          'Réévaluation à 48-72h'
        ]
      };
    } else {
      riskAssessment = {
        level: 'Faible',
        color: 'text-green-600',
        recommendations: [
          'Traitement ambulatoire possible',
          'Anticoagulation conventionnelle',
          'Suivi à 1 semaine',
          'Éducation thérapeutique'
        ]
      };
    }

    setRisk(riskAssessment as typeof risk);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Calculator className="w-5 h-5 text-blue-600" />
        Calculateur EP - Évaluation Échocardiographique
      </h2>

      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            label="Ratio VD/VG"
            name="vdvgRatio"
            value={values.vdvgRatio}
            onChange={handleChange('vdvgRatio')}
            description="Rapport des diamètres VD/VG en 4 cavités"
            placeholder="Ex: 0.8"
          />
          
          <FormField
            label="TAPSE"
            name="tapse"
            value={values.tapse}
            onChange={handleChange('tapse')}
            description="Excursion systolique de l'anneau tricuspide en mm"
            placeholder="Ex: 18"
          />
          
          <FormField
            label="Onde S' tricuspide"
            name="waveS"
            value={values.waveS}
            onChange={handleChange('waveS')}
            description="Vitesse de l'onde S' à l'anneau tricuspide en cm/s"
            placeholder="Ex: 10"
          />
          
          <FormField
            label="PAPs"
            name="paps"
            value={values.paps}
            onChange={handleChange('paps')}
            description="Pression artérielle pulmonaire systolique en mmHg"
            placeholder="Ex: 45"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="flex items-center gap-3 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
            <input
              type="checkbox"
              checked={values.rvDilation}
              onChange={(e) => handleChange('rvDilation')(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span>Dilatation VD</span>
          </label>

          <label className="flex items-center gap-3 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
            <input
              type="checkbox"
              checked={values.paradoxicalSeptum}
              onChange={(e) => handleChange('paradoxicalSeptum')(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span>Septum paradoxal</span>
          </label>

          <label className="flex items-center gap-3 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
            <input
              type="checkbox"
              checked={values.visibleThrombus}
              onChange={(e) => handleChange('visibleThrombus')(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span>Thrombus visible</span>
          </label>

          <label className="flex items-center gap-3 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
            <input
              type="checkbox"
              checked={values.mcConnell}
              onChange={(e) => handleChange('mcConnell')(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span>Signe de McConnell</span>
          </label>
        </div>

        <div className="flex justify-center">
          <button
            onClick={calculateRisk}
            className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg 
                     hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 
                     focus:ring-offset-2 transition-colors duration-200"
          >
            Évaluer le Risque
          </button>
        </div>

        {risk && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <span className="font-medium text-gray-900">Niveau de risque:</span>
              <span className={`text-lg font-bold ${risk.color}`}>
                {risk.level}
              </span>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-medium text-gray-900">Recommandations:</h4>
              <ul className="list-disc list-inside space-y-1 text-gray-600">
                {risk.recommendations.map((rec, index) => (
                  <li key={index}>{rec}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}