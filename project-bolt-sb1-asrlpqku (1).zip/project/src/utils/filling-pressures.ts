import type { FillingPressuresInterpretation } from '../types/filling-pressures';

interface InterpretationParams {
  eToAverageTdRatio: number;
  eToARatio?: number;
  decelerationTime: number;
  preservedEF: boolean;
  paps?: number;
  leftAtrialVolume?: number;
  hasAtrialFibrillation: boolean;
}

export function interpretResults({
  eToAverageTdRatio,
  eToARatio,
  decelerationTime,
  preservedEF,
  paps,
  leftAtrialVolume,
  hasAtrialFibrillation,
}: InterpretationParams): FillingPressuresInterpretation {
  const additionalFindings: string[] = [];

  if (hasAtrialFibrillation) {
    additionalFindings.push('Fibrillation atriale: onde A non mesurable');
  }

  // Analyze PAPS
  if (paps !== undefined) {
    if (paps > 50) {
      additionalFindings.push(`HTAP sévère (PAPS = ${paps} mmHg)`);
    } else if (paps > 35) {
      additionalFindings.push(`HTAP modérée (PAPS = ${paps} mmHg)`);
    } else if (paps > 25) {
      additionalFindings.push(`HTAP légère (PAPS = ${paps} mmHg)`);
    }
  }

  // Analyze Left Atrial Volume
  if (leftAtrialVolume !== undefined) {
    if (leftAtrialVolume > 34) {
      additionalFindings.push(`Dilatation OG (Volume = ${leftAtrialVolume} mL)`);
    }
  }

  if (preservedEF) {
    // Algorithm for preserved EF
    if (eToAverageTdRatio < 8) {
      return {
        conclusion: "Pressions de remplissage normales",
        details: "E/e' < 8 suggère des pressions normales",
        color: "text-green-600",
        additionalFindings,
      };
    } else if (eToAverageTdRatio > 14) {
      return {
        conclusion: "Pressions de remplissage élevées",
        details: "E/e' > 14 indique des pressions élevées",
        color: "text-red-600",
        additionalFindings,
      };
    } else {
      // Zone grise (8-14)
      const hasAdditionalCriteria = 
        (!hasAtrialFibrillation && eToARatio !== undefined && eToARatio > 2) || 
        decelerationTime < 160 || 
        (paps !== undefined && paps > 35) ||
        (leftAtrialVolume !== undefined && leftAtrialVolume > 34);

      if (hasAdditionalCriteria) {
        return {
          conclusion: "Pressions de remplissage probablement élevées",
          details: "Zone grise avec critères additionnels suggérant des pressions élevées",
          color: "text-orange-600",
          additionalFindings,
        };
      }
      return {
        conclusion: "Pressions de remplissage indéterminées",
        details: "Zone grise sans critères additionnels concluants",
        color: "text-yellow-600",
        additionalFindings,
      };
    }
  } else {
    // Algorithm for reduced EF
    if (eToAverageTdRatio < 8) {
      return {
        conclusion: "Pressions de remplissage normales",
        details: "E/e' < 8 suggère des pressions normales malgré la FEVG altérée",
        color: "text-green-600",
        additionalFindings,
      };
    } else if (eToAverageTdRatio > 14) {
      return {
        conclusion: "Pressions de remplissage élevées",
        details: "E/e' > 14 indique des pressions élevées avec FEVG altérée",
        color: "text-red-600",
        additionalFindings,
      };
    } else {
      return {
        conclusion: "Pressions de remplissage probablement élevées",
        details: "E/e' intermédiaire avec FEVG altérée suggère des pressions élevées",
        color: "text-orange-600",
        additionalFindings,
      };
    }
  }
}