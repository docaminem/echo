import React, { useState } from 'react';
import { ArrowDownCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function PulmonaryStenosis() {
  const [values, setValues] = useState({
    meanGradient: '',
    maxVelocity: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-orange-700">
        <ArrowDownCircle className="w-4 h-4" />
        Sténose Pulmonaire
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="Gradient Moyen"
          name="pulmonaryStenosisMeanGradient"
          value={values.meanGradient}
          onChange={handleChange('meanGradient')}
          description="Gradient moyen transpulmonaire en mmHg"
          placeholder="Ex: 25"
        />
        
        <FormField
          label="Vitesse Max"
          name="pulmonaryStenosisMaxVelocity"
          value={values.maxVelocity}
          onChange={handleChange('maxVelocity')}
          description="Vitesse maximale transpulmonaire en m/s"
          placeholder="Ex: 3.5"
        />
      </div>
    </div>
  );
}