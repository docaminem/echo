import React, { useState } from 'react';
import { ArrowUpCircle } from 'lucide-react';
import { FormField } from '../../common/FormField';

export function AorticInsufficiency() {
  const [values, setValues] = useState({
    venaContracta: '',
    pht: '',
    lvotRatio: ''
  });

  const handleChange = (name: string) => (value: string) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-4">
      <h4 className="text-md font-medium flex items-center gap-2 text-red-700">
        <ArrowUpCircle className="w-4 h-4" />
        Insuffisance Aortique
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          label="Vena Contracta"
          name="aorticInsufficiencyVenaContracta"
          value={values.venaContracta}
          onChange={handleChange('venaContracta')}
          description="Largeur de la vena contracta en mm"
          placeholder="Ex: 5"
        />
        
        <FormField
          label="PHT"
          name="aorticInsufficiencyPht"
          value={values.pht}
          onChange={handleChange('pht')}
          description="Temps de demi-décroissance en ms"
          placeholder="Ex: 300"
        />
        
        <FormField
          label="Ratio LVOT/Aorte"
          name="aorticInsufficiencyLvotRatio"
          value={values.lvotRatio}
          onChange={handleChange('lvotRatio')}
          description="Ratio des flux LVOT/Aorte ascendante"
          placeholder="Ex: 0.6"
        />
      </div>
    </div>
  );
}