import { ValveData, DiagnosisResult } from '../../types/valve';

export function analyzePulmonaryStenosis(data: ValveData['pulmonary']['stenosis']): DiagnosisResult | null {
  if (!data.meanGradient && !data.maxVelocity) return null;

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  if (data.meanGradient) {
    details.push(`Gradient moyen: ${data.meanGradient} mmHg`);
    if (data.meanGradient >= 40) severity = 'Sévère';
    else if (data.meanGradient >= 20) severity = 'Modérée';
    else if (data.meanGradient >= 10) severity = 'Légère';
  }

  if (data.maxVelocity) {
    details.push(`Vitesse maximale: ${data.maxVelocity} m/s`);
    if (data.maxVelocity >= 4.0) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.maxVelocity >= 3.0) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Pulmonaire',
    pathology: 'Sténose',
    severity,
    details
  };
}

export function analyzePulmonaryInsufficiency(data: ValveData['pulmonary']['insufficiency']): DiagnosisResult | null {
  if (!data.venaContracta && !data.pht) return null;

  let severity: 'Légère' | 'Modérée' | 'Sévère' | 'Normal' = 'Normal';
  const details: string[] = [];

  if (data.venaContracta) {
    details.push(`Vena contracta: ${data.venaContracta} mm`);
    if (data.venaContracta >= 7) severity = 'Sévère';
    else if (data.venaContracta >= 3) severity = 'Modérée';
    else if (data.venaContracta >= 1) severity = 'Légère';
  }

  if (data.pht) {
    details.push(`PHT: ${data.pht} ms`);
    if (data.pht <= 100) {
      severity = severity === 'Normal' ? 'Sévère' : severity;
    } else if (data.pht <= 200) {
      severity = severity === 'Normal' ? 'Modérée' : severity;
    }
  }

  if (severity === 'Normal') return null;

  return {
    valve: 'Pulmonaire',
    pathology: 'Insuffisance',
    severity,
    details
  };
}